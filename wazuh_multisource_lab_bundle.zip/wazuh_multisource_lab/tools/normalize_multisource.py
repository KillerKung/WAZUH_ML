#!/usr/bin/env python3
"""Normalize Wazuh, Suricata, and Auditd alerts into a leakage-safe dataset."""

from __future__ import annotations

import argparse
import hashlib
import ipaddress
import json
from collections import defaultdict, deque
from datetime import timedelta
from pathlib import Path
from typing import Any, Iterable

import pandas as pd


VALID_GROUPS = {"Normal", "Pre_Compromise", "Post_Compromise"}
FAILED_ACTIONS = {"ssh_login_failed", "login_failed", "authentication_failed"}
SCAN_ACTIONS = {"network_scan", "service_scan", "web_scan", "wordpress_scan", "port_scan"}
PRIVILEGE_ACTIONS = {"sudo_group_change", "privilege_escalation", "permission_change"}
STAGE_WEIGHTS = {
    "network_scan": 1,
    "service_scan": 1,
    "web_scan": 2,
    "wordpress_scan": 2,
    "ssh_login_failed": 3,
    "ssh_login_success": 4,
    "suspicious_php_created": 5,
    "web_process_spawned_shell": 6,
    "sudo_group_change": 7,
}


def nested(item: Any, path: str, default: Any = None) -> Any:
    value = item
    for key in path.split("."):
        if not isinstance(value, dict) or key not in value:
            return default
        value = value[key]
    return value


def first(*values: Any, default: Any = None) -> Any:
    return next((value for value in values if value not in (None, "")), default)


def read_jsonl(path: Path) -> Iterable[dict[str, Any]]:
    with path.open("r", encoding="utf-8") as stream:
        for line_number, line in enumerate(stream, 1):
            if not line.strip():
                continue
            try:
                item = json.loads(line)
            except json.JSONDecodeError as exc:
                raise ValueError(f"{path}:{line_number}: invalid JSON: {exc}") from exc
            if not isinstance(item, dict):
                raise ValueError(f"{path}:{line_number}: expected a JSON object")
            yield item


def parse_full_log(alert: dict[str, Any]) -> dict[str, Any]:
    raw = alert.get("full_log")
    if not isinstance(raw, str):
        return {}
    try:
        value = json.loads(raw)
    except json.JSONDecodeError:
        return {}
    return value if isinstance(value, dict) else {}


def groups_text(value: Any) -> str:
    if isinstance(value, list):
        return "|".join(sorted(str(item) for item in value))
    return str(value or "unknown")


def private_ip(value: str) -> int:
    try:
        return int(ipaddress.ip_address(value).is_private)
    except ValueError:
        return 0


def integer(value: Any, default: int = 0) -> int:
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


def detect_source(alert: dict, data: dict, payload: dict, groups: str, location: str) -> str:
    explicit = first(
        alert.get("source_system"), data.get("source_system"), payload.get("source_system"),
        nested(alert, "labels.source_system"),
    )
    if explicit:
        return str(explicit).lower()
    haystack = " ".join((groups, location, str(nested(alert, "decoder.name", "")))).lower()
    if "suricata" in haystack or data.get("event_type") in {"alert", "flow", "dns", "http"}:
        return "suricata"
    if "audit" in haystack or "audit" in data or any(str(key).startswith("audit.") for key in data):
        return "auditd"
    return "wazuh"


def derive_action(source: str, data: dict, payload: dict, signature: str, audit_key: str) -> str:
    explicit = first(
        nested(data, "event.action"), nested(payload, "event.action"),
        data.get("action"), payload.get("action"),
    )
    if explicit:
        return str(explicit).lower()
    text = f"{signature} {audit_key}".lower()
    if source == "suricata":
        if "web" in text and "scan" in text:
            return "web_scan"
        if any(token in text for token in ("scan", "recon", "nmap")):
            return "network_scan"
        return str(data.get("event_type") or payload.get("event_type") or "network_event").lower()
    if source == "auditd":
        if any(token in text for token in ("privilege", "sudo", "identity")):
            return "privilege_change"
        if "file" in text:
            return "audit_file_change"
        if "exec" in text:
            return "audit_process_execution"
        return "audit_event"
    return "unknown"


def fallback_id(alert: dict, row_number: int) -> str:
    basis = json.dumps(alert, ensure_ascii=False, sort_keys=True).encode("utf-8")
    return f"derived-{hashlib.sha256(basis).hexdigest()[:20]}-{row_number}"


def extract(alert: dict[str, Any], row_number: int) -> dict[str, Any]:
    payload = parse_full_log(alert)
    data = alert.get("data") if isinstance(alert.get("data"), dict) else {}
    groups = groups_text(first(nested(alert, "rule.groups"), nested(payload, "rule.groups"), default=[]))
    location = str(alert.get("location", "unknown"))
    source = detect_source(alert, data, payload, groups, location)

    signature = str(first(nested(data, "alert.signature"), nested(payload, "alert.signature"), default=""))
    audit_key = str(first(nested(data, "audit.key"), nested(payload, "audit.key"), data.get("key"), default=""))
    action = derive_action(source, data, payload, signature, audit_key)
    src_ip = str(first(data.get("src_ip"), data.get("srcip"), nested(payload, "network.src_ip"), payload.get("src_ip"), nested(alert, "network.src_ip"), alert.get("source_ip"), default=""))
    dst_ip = str(first(data.get("dest_ip"), data.get("dstip"), nested(payload, "network.dest_ip"), payload.get("dest_ip"), nested(alert, "network.dest_ip"), default=""))
    action = str(first(nested(alert, "event.action"), action)).lower()
    process = str(first(nested(data, "audit.process.name"), nested(data, "audit.exe"), nested(payload, "audit.process"), nested(alert, "audit.process"), default=""))
    parent = str(first(nested(data, "audit.parent_process.name"), nested(payload, "audit.parent_process"), nested(alert, "audit.parent_process"), default=""))
    mitre = first(nested(alert, "rule.mitre.id"), nested(payload, "mitre.id"), default=[])
    if isinstance(mitre, list):
        mitre = "|".join(sorted(str(item) for item in mitre)) or "none"

    return {
        "event_id": str(first(alert.get("event_id"), alert.get("id"), data.get("event_id"), payload.get("event_id"), default=fallback_id(alert, row_number))),
        "operation_id": str(first(alert.get("operation_id"), data.get("operation_id"), payload.get("operation_id"), default="unknown-operation")),
        "timestamp": first(alert.get("timestamp"), payload.get("timestamp")),
        "source_system": source,
        "event_type": str(first(data.get("event_type"), payload.get("event_type"), nested(data, "event.category"), nested(payload, "event.category"), nested(alert, "event.category"), default="unknown")),
        "agent_name": str(first(nested(alert, "agent.name"), nested(payload, "agent.name"), default="unknown")),
        "rule_id": str(first(nested(alert, "rule.id"), nested(payload, "rule.id"), default="unknown")),
        "rule_level": integer(first(nested(alert, "rule.level"), nested(payload, "rule.level"), default=0)),
        "rule_groups": groups,
        "decoder_name": str(first(nested(alert, "decoder.name"), default="unknown")),
        "event_action": action,
        "event_status": str(first(nested(data, "event.status"), nested(payload, "event.status"), nested(alert, "event.status"), default="unknown")),
        "mitre_id": str(mitre or "none"),
        "protocol": str(first(data.get("proto"), payload.get("proto"), nested(payload, "network.protocol"), nested(alert, "network.protocol"), default="unknown")).upper(),
        "source_port": integer(first(data.get("src_port"), nested(payload, "network.src_port"), nested(alert, "network.src_port"), default=0)),
        "destination_port": integer(first(data.get("dest_port"), data.get("dstport"), nested(payload, "network.dest_port"), nested(alert, "network.dest_port"), default=0)),
        "source_is_private": private_ip(src_ip),
        "destination_is_private": private_ip(dst_ip),
        "network_bytes": integer(first(data.get("bytes_toserver"), nested(payload, "network.bytes"), default=0)),
        "network_packets": integer(first(data.get("pkts_toserver"), nested(payload, "network.packets"), default=0)),
        "audit_event_present": int(source == "auditd"),
        "process_present": int(bool(process)),
        "parent_process_present": int(bool(parent)),
        "file_change": int(source == "auditd" and ("file" in audit_key.lower() or "file" in action)),
        "privilege_change": int(source == "auditd" and (action in PRIVILEGE_ACTIONS or any(token in audit_key.lower() for token in ("privilege", "sudo", "identity")))),
        "asset_importance": 9 if "server" in str(nested(alert, "agent.name", "")).lower() else 5,
        "stage_weight": STAGE_WEIGHTS.get(action, 0),
        "source_key_internal": src_ip or f"no-source:{row_number}",
        "destination_key_internal": str(first(nested(alert, "agent.name"), nested(payload, "agent.name"), dst_ip, default="unknown")),
        "audit_session_internal": str(first(nested(data, "audit.session"), nested(payload, "audit.session"), default="")),
    }


def trim(queue: deque, cutoff: pd.Timestamp) -> None:
    while queue and queue[0] < cutoff:
        queue.popleft()


def add_behavior(frame: pd.DataFrame) -> pd.DataFrame:
    frame = frame.copy()
    frame["timestamp"] = pd.to_datetime(frame["timestamp"], utc=True, errors="coerce")
    if frame["timestamp"].isna().any():
        raise ValueError(f"{int(frame['timestamp'].isna().sum())} event(s) have invalid timestamps")
    frame = frame.sort_values(["timestamp", "event_id"]).reset_index(drop=True)

    source_events: dict[str, deque] = defaultdict(deque)
    failed_events: dict[str, deque] = defaultdict(deque)
    scan_events: dict[str, deque] = defaultdict(deque)
    host_events: dict[str, deque] = defaultdict(deque)
    host_network: dict[str, deque] = defaultdict(deque)
    host_audit: dict[str, deque] = defaultdict(deque)
    host_process: dict[str, deque] = defaultdict(deque)
    host_file: dict[str, deque] = defaultdict(deque)
    host_privilege: dict[str, deque] = defaultdict(deque)
    host_sources: dict[str, deque] = defaultdict(deque)
    host_stages: dict[str, deque] = defaultdict(deque)
    features: list[dict[str, int]] = []

    for row in frame.itertuples(index=False):
        now = row.timestamp
        # Keep rolling windows inside one controlled operation so separate lab
        # runs cannot contaminate each other's behavioral features.
        source_key = f"{row.operation_id}:{row.source_key_internal}"
        host_key = f"{row.operation_id}:{row.destination_key_internal or row.agent_name}"
        for queue, minutes in (
            (source_events[source_key], 5), (failed_events[source_key], 10), (scan_events[source_key], 5),
            (host_events[host_key], 5), (host_network[host_key], 5), (host_audit[host_key], 5),
            (host_process[host_key], 10), (host_file[host_key], 10), (host_privilege[host_key], 30),
        ):
            trim(queue, now - timedelta(minutes=minutes))
        while host_sources[host_key] and host_sources[host_key][0][0] < now - timedelta(minutes=10):
            host_sources[host_key].popleft()
        while host_stages[host_key] and host_stages[host_key][0][0] < now - timedelta(minutes=30):
            host_stages[host_key].popleft()

        previous_stages = [stage for _, stage in host_stages[host_key]]
        features.append({
            "source_events_previous_5m": len(source_events[source_key]),
            "failed_logins_previous_10m": len(failed_events[source_key]),
            "scans_previous_5m": len(scan_events[source_key]),
            "host_events_previous_5m": len(host_events[host_key]),
            "network_alerts_previous_5m": len(host_network[host_key]),
            "audit_events_previous_5m": len(host_audit[host_key]),
            "process_executions_previous_10m": len(host_process[host_key]),
            "file_changes_previous_10m": len(host_file[host_key]),
            "privilege_changes_previous_30m": len(host_privilege[host_key]),
            "cross_source_count_previous_10m": len({source for _, source in host_sources[host_key]}),
            "previous_stage_max_30m": max(previous_stages, default=0),
            "chain_length_previous_30m": len(previous_stages),
        })

        source_events[source_key].append(now)
        host_events[host_key].append(now)
        host_sources[host_key].append((now, row.source_system))
        if row.event_action in FAILED_ACTIONS:
            failed_events[source_key].append(now)
        if row.event_action in SCAN_ACTIONS:
            scan_events[source_key].append(now)
        if row.source_system == "suricata":
            host_network[host_key].append(now)
        if row.source_system == "auditd":
            host_audit[host_key].append(now)
        if row.process_present:
            host_process[host_key].append(now)
        if row.file_change:
            host_file[host_key].append(now)
        if row.privilege_change:
            host_privilege[host_key].append(now)
        if row.stage_weight:
            host_stages[host_key].append((now, int(row.stage_weight)))

    frame = pd.concat([frame, pd.DataFrame(features)], axis=1)
    frame["hour"] = frame["timestamp"].dt.hour
    frame["day_of_week"] = frame["timestamp"].dt.dayofweek
    frame["is_after_hours"] = ((frame["hour"] < 8) | (frame["hour"] >= 18)).astype(int)
    return frame


def merge_labels(frame: pd.DataFrame, path: Path) -> pd.DataFrame:
    labels = pd.DataFrame(read_jsonl(path))
    required = {"event_id", "attack_type", "attack_group"}
    missing = required - set(labels.columns)
    if missing:
        raise ValueError(f"labels missing columns: {sorted(missing)}")
    unknown = set(labels["attack_group"].dropna()) - VALID_GROUPS
    if unknown:
        raise ValueError(f"unknown attack groups: {sorted(unknown)}")
    if labels["event_id"].duplicated().any():
        raise ValueError("labels contain duplicate event_id")
    return frame.merge(labels[["event_id", "attack_type", "attack_group"]], on="event_id", how="left", validate="one_to_one")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--alerts", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--labels", type=Path)
    args = parser.parse_args()

    rows = [extract(item, index) for index, item in enumerate(read_jsonl(args.alerts), 1)]
    if not rows:
        parser.error("alerts input is empty")
    frame = add_behavior(pd.DataFrame(rows))
    if args.labels:
        frame = merge_labels(frame, args.labels)
    internal = ["source_key_internal", "destination_key_internal", "audit_session_internal"]
    frame = frame.drop(columns=internal)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    frame.to_csv(args.output, index=False)
    print(json.dumps({
        "rows": len(frame),
        "sources": frame["source_system"].value_counts().to_dict(),
        "operations": int(frame["operation_id"].nunique()),
        "output": str(args.output.resolve()),
    }, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
