#!/usr/bin/env python3
"""Predict lifecycle class and priority for normalized multi-source alerts."""

from __future__ import annotations

import argparse
from pathlib import Path

import joblib
import pandas as pd


def priority_name(score: float) -> str:
    if score >= 81:
        return "Critical"
    if score >= 61:
        return "High"
    if score >= 31:
        return "Medium"
    return "Low"


def numeric_column(frame: pd.DataFrame, name: str, default: float) -> pd.Series:
    values = frame[name] if name in frame else pd.Series(default, index=frame.index)
    return pd.to_numeric(values, errors="coerce").fillna(default)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--model", type=Path, required=True)
    parser.add_argument("--dataset", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()

    bundle = joblib.load(args.model)
    frame = pd.read_csv(args.dataset)
    features = bundle["feature_columns"]
    missing = set(features) - set(frame.columns)
    if missing:
        raise ValueError(f"inference dataset missing features: {sorted(missing)}")
    probabilities = bundle["pipeline"].predict_proba(frame[features])
    predicted = probabilities.argmax(axis=1)
    id_to_label = {int(key): value for key, value in bundle["id_to_label"].items()}

    result = frame[[column for column in ("event_id", "operation_id", "source_system", "event_action") if column in frame]].copy()
    result["predicted_group"] = [id_to_label[int(value)] for value in predicted]
    for class_id, class_name in id_to_label.items():
        result[f"probability_{class_name}"] = probabilities[:, class_id]

    rule_level = numeric_column(frame, "rule_level", 0).clip(0, 15)
    asset = numeric_column(frame, "asset_importance", 5).clip(1, 10)
    chain = numeric_column(frame, "chain_length_previous_30m", 0).clip(0, 20)
    post_probability = result["probability_Post_Compromise"]
    result["priority_score"] = (post_probability * 65 + rule_level * 1.5 + asset + chain * 0.5).clip(0, 100).round(2)
    result["priority"] = result["priority_score"].map(priority_name)
    result = result.sort_values("priority_score", ascending=False)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    result.to_csv(args.output, index=False)
    print(f"wrote {len(result)} predictions to {args.output.resolve()}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
