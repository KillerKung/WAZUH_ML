#!/usr/bin/env python3
"""Idempotently configure Wazuh localfiles and Suricata lab settings."""

from __future__ import annotations

import argparse
import re
import shutil
from datetime import datetime, timezone
from pathlib import Path


LAB_BEGIN = "  <!-- BEGIN WAZUH MULTISOURCE LAB -->"
LAB_END = "  <!-- END WAZUH MULTISOURCE LAB -->"
LAB_BLOCK = f"""{LAB_BEGIN}
  <localfile>
    <log_format>json</log_format>
    <location>/var/log/suricata/eve.json</location>
    <label key="source_system">suricata</label>
  </localfile>
  <localfile>
    <log_format>audit</log_format>
    <location>/var/log/audit/audit.log</location>
  </localfile>
  <localfile>
    <log_format>json</log_format>
    <location>/opt/wazuh-lab/events.jsonl</location>
    <label key="source_system">lab_simulator</label>
  </localfile>
{LAB_END}
"""


def backup(path: Path) -> Path:
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
    target = path.with_name(f"{path.name}.wazuh-lab.{stamp}.bak")
    shutil.copy2(path, target)
    return target


def configure_ossec(path: Path) -> None:
    text = path.read_text(encoding="utf-8")
    if LAB_BEGIN in text and LAB_END in text:
        pattern = re.escape(LAB_BEGIN) + r".*?" + re.escape(LAB_END) + r"\n?"
        text = re.sub(pattern, LAB_BLOCK, text, flags=re.DOTALL)
    else:
        position = text.rfind("</ossec_config>")
        if position < 0:
            raise ValueError(f"{path} has no closing </ossec_config>")
        text = text[:position] + LAB_BLOCK + text[position:]
    path.write_text(text, encoding="utf-8")


def configure_suricata(path: Path, interface: str, home_net: str) -> None:
    text = path.read_text(encoding="utf-8")
    text, home_count = re.subn(
        r'(?m)^(\s*HOME_NET\s*:\s*).+$',
        lambda match: f'{match.group(1)}"[{home_net}]"',
        text,
        count=1,
    )
    if not home_count:
        raise ValueError(f"HOME_NET was not found in {path}")

    af_packet = re.search(r"(?ms)^af-packet:\s*\n(?P<body>.*?)(?=^[A-Za-z0-9_-]+:|\Z)", text)
    if not af_packet:
        raise ValueError(f"af-packet section was not found in {path}")
    body = af_packet.group("body")
    new_body, interface_count = re.subn(
        r"(?m)^(\s*-\s*interface\s*:\s*).+$",
        lambda match: f"{match.group(1)}{interface}",
        body,
        count=1,
    )
    if not interface_count:
        raise ValueError(f"af-packet interface was not found in {path}")
    text = text[: af_packet.start("body")] + new_body + text[af_packet.end("body") :]

    lab_rule = "/etc/suricata/rules/wazuh-lab.rules"
    if lab_rule not in text:
        text, rule_count = re.subn(
            r"(?m)^(\s*rule-files\s*:\s*)$",
            lambda match: f"{match.group(1)}\n  - {lab_rule}",
            text,
            count=1,
        )
        if not rule_count:
            raise ValueError(f"rule-files section was not found in {path}")
    path.write_text(text, encoding="utf-8")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--ossec", type=Path, required=True)
    parser.add_argument("--suricata", type=Path, required=True)
    parser.add_argument("--interface", required=True)
    parser.add_argument("--home-net", required=True)
    args = parser.parse_args()

    for path in (args.ossec, args.suricata):
        if not path.is_file():
            parser.error(f"file not found: {path}")
        saved = backup(path)
        print(f"backup: {saved}")

    configure_ossec(args.ossec)
    configure_suricata(args.suricata, args.interface, args.home_net)
    print("sensor configuration updated")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
