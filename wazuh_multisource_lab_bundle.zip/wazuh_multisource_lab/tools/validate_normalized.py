#!/usr/bin/env python3
"""Validate normalized multi-source CSV before ML training."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import pandas as pd


REQUIRED = {
    "event_id", "operation_id", "timestamp", "source_system", "event_type",
    "rule_level", "event_action", "network_alerts_previous_5m",
    "audit_events_previous_5m", "cross_source_count_previous_10m",
    "chain_length_previous_30m",
}
FORBIDDEN_TOKENS = ("provenance", "marker", "session_id", "raw_log", "source_ip", "username")
VALID_GROUPS = {"Normal", "Pre_Compromise", "Post_Compromise"}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("dataset", type=Path)
    args = parser.parse_args()
    frame = pd.read_csv(args.dataset)
    errors: list[str] = []

    missing = REQUIRED - set(frame.columns)
    if missing:
        errors.append(f"missing columns: {sorted(missing)}")
    leaked = [column for column in frame.columns if any(token in column.lower() for token in FORBIDDEN_TOKENS)]
    if leaked:
        errors.append(f"possible leakage columns: {leaked}")
    if "attack_group" in frame:
        unknown = set(frame["attack_group"].dropna()) - VALID_GROUPS
        if unknown:
            errors.append(f"unknown attack groups: {sorted(unknown)}")
    numeric = frame.select_dtypes(include="number")
    if any(not math.isfinite(float(value)) for value in numeric.to_numpy().ravel() if not pd.isna(value)):
        errors.append("numeric data contains infinity")
    if frame.empty:
        errors.append("dataset is empty")

    result = {
        "valid": not errors,
        "rows": len(frame),
        "columns": len(frame.columns),
        "sources": frame["source_system"].value_counts().to_dict() if "source_system" in frame else {},
        "errors": errors,
    }
    print(json.dumps(result, indent=2))
    return 0 if not errors else 1


if __name__ == "__main__":
    raise SystemExit(main())

