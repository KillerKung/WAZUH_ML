#!/usr/bin/env python3
"""Generate safe, synthetic Wazuh/Suricata/Auditd events and separate labels."""

from __future__ import annotations

import argparse
import json
import random
import uuid
from datetime import datetime, timedelta, timezone
from pathlib import Path


ATTACK_GROUP = {
    "Normal": "Normal",
    "Network_Scan": "Pre_Compromise",
    "Web_Scan": "Pre_Compromise",
    "Brute_Force": "Pre_Compromise",
    "Compromised_Login": "Post_Compromise",
    "Web_Shell": "Post_Compromise",
    "Privilege_Escalation": "Post_Compromise",
}


def iso(value: datetime) -> str:
    return value.astimezone(timezone.utc).isoformat().replace("+00:00", "Z")


def emit(
    operation_id: str,
    when: datetime,
    source_system: str,
    action: str,
    attack_type: str,
    **fields: object,
) -> tuple[dict[str, object], dict[str, object]]:
    event_id = f"lab-{uuid.uuid4()}"
    event = {
        "event_id": event_id,
        "operation_id": operation_id,
        "timestamp": iso(when),
        "source_system": source_system,
        "agent": {"name": "lab-sensor-01"},
        "event": {
            "category": fields.pop("category", "security"),
            "action": action,
            "status": fields.pop("status", "observed"),
        },
        **fields,
    }
    label = {
        "event_id": event_id,
        "operation_id": operation_id,
        "attack_type": attack_type,
        "attack_group": ATTACK_GROUP[attack_type],
        "provenance": "controlled_lab_synthetic",
    }
    return event, label


def build(operation_id: str, seed: int, normal_count: int) -> tuple[list[dict], list[dict]]:
    rng = random.Random(seed)
    now = datetime.now(timezone.utc).replace(microsecond=0) - timedelta(minutes=20)
    items: list[tuple[dict, dict]] = []

    normal_actions = ["http_request", "dns_query", "package_check", "user_command"]
    for index in range(normal_count):
        action = rng.choice(normal_actions)
        source = "suricata" if action in {"http_request", "dns_query"} else "auditd"
        source_fields = (
            {"network": {"protocol": rng.choice(["TCP", "UDP"]), "src_ip": "192.168.56.40", "dest_ip": "192.168.56.20", "src_port": rng.randint(20000, 60000), "dest_port": 80}}
            if source == "suricata"
            else {"audit": {"process": "apt" if action == "package_check" else "true", "key": "normal_activity"}}
        )
        items.append(emit(
            operation_id, now + timedelta(seconds=index * 8), source, action, "Normal",
            category="network" if source == "suricata" else "host",
            **source_fields,
        ))

    cursor = now + timedelta(minutes=5)
    for index in range(12):
        items.append(emit(
            operation_id, cursor + timedelta(seconds=index * 3), "suricata", "network_scan", "Network_Scan",
            category="network", status="detected", mitre={"id": ["T1046"]},
            network={"protocol": "TCP", "src_ip": "192.168.56.30", "dest_ip": "192.168.56.20", "src_port": 41000 + index, "dest_port": 20 + index},
        ))
    cursor += timedelta(minutes=2)
    for index in range(7):
        items.append(emit(
            operation_id, cursor + timedelta(seconds=index * 4), "suricata", "web_scan", "Web_Scan",
            category="network", status="detected", mitre={"id": ["T1595.003"]},
            network={"protocol": "TCP", "src_ip": "192.168.56.30", "dest_ip": "192.168.56.20", "src_port": 42000 + index, "dest_port": 80},
        ))
    cursor += timedelta(minutes=2)
    for index in range(10):
        items.append(emit(
            operation_id, cursor + timedelta(seconds=index * 5), "wazuh", "ssh_login_failed", "Brute_Force",
            category="authentication", status="failure", mitre={"id": ["T1110"]},
            authentication={"method": "ssh", "result": "failure"},
        ))
    cursor += timedelta(minutes=2)
    items.append(emit(
        operation_id, cursor, "wazuh", "ssh_login_success", "Compromised_Login",
        category="authentication", status="success", mitre={"id": ["T1078"]},
        authentication={"method": "ssh", "result": "success"},
    ))
    items.append(emit(
        operation_id, cursor + timedelta(seconds=20), "auditd", "web_process_spawned_shell", "Web_Shell",
        category="process", status="success", mitre={"id": ["T1059.004"]},
        audit={"process": "sh", "parent_process": "apache2", "key": "wazuh_lab_exec"},
    ))
    items.append(emit(
        operation_id, cursor + timedelta(seconds=40), "auditd", "sudo_group_change", "Privilege_Escalation",
        category="privilege", status="success", mitre={"id": ["T1098"]},
        audit={"process": "usermod", "parent_process": "sudo", "key": "wazuh_lab_privilege"},
    ))

    items.sort(key=lambda pair: str(pair[0]["timestamp"]))
    return [item[0] for item in items], [item[1] for item in items]


def write_jsonl(path: Path, rows: list[dict], append: bool) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    mode = "a" if append else "w"
    with path.open(mode, encoding="utf-8") as stream:
        for row in rows:
            stream.write(json.dumps(row, ensure_ascii=False) + "\n")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--operation-id", required=True)
    parser.add_argument("--output", type=Path, default=Path("data/events.jsonl"))
    parser.add_argument("--labels", type=Path, default=Path("data/labels.jsonl"))
    parser.add_argument("--normal-count", type=int, default=20)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--append", action="store_true")
    args = parser.parse_args()
    if args.normal_count < 1:
        parser.error("--normal-count must be positive")

    events, labels = build(args.operation_id, args.seed, args.normal_count)
    write_jsonl(args.output, events, args.append)
    write_jsonl(args.labels, labels, args.append)
    counts: dict[str, int] = {}
    for label in labels:
        name = str(label["attack_group"])
        counts[name] = counts.get(name, 0) + 1
    print(json.dumps({"events": len(events), "classes": counts}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
