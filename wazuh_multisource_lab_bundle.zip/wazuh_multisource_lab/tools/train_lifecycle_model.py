#!/usr/bin/env python3
"""Train the three-class multi-source attack-lifecycle XGBoost model."""

from __future__ import annotations

import argparse
import json
from datetime import datetime, timezone
from pathlib import Path

import joblib
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.metrics import classification_report, confusion_matrix
from sklearn.model_selection import GroupShuffleSplit
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder
from sklearn.utils.class_weight import compute_sample_weight
from xgboost import XGBClassifier


LABEL_TO_ID = {"Normal": 0, "Pre_Compromise": 1, "Post_Compromise": 2}
ID_TO_LABEL = {value: key for key, value in LABEL_TO_ID.items()}
NEVER_FEATURES = {
    "event_id", "operation_id", "timestamp", "attack_type", "attack_group",
    "provenance", "source_ip", "destination_ip", "username", "raw_log",
    "full_log", "audit_session_id",
}
FORBIDDEN_TOKENS = ("provenance", "marker", "session_id", "raw_log", "source_ip", "username")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--dataset", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, default=Path("artifacts"))
    parser.add_argument("--test-size", type=float, default=0.25)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--n-estimators", type=int, default=300)
    args = parser.parse_args()
    if not 0 < args.test_size < 1:
        parser.error("--test-size must be between 0 and 1")

    frame = pd.read_csv(args.dataset).dropna(subset=["attack_group"]).copy()
    required = {"event_id", "operation_id", "attack_group"}
    missing = required - set(frame.columns)
    if missing:
        raise ValueError(f"dataset missing columns: {sorted(missing)}")
    unknown = set(frame["attack_group"]) - set(LABEL_TO_ID)
    if unknown:
        raise ValueError(f"unknown labels: {sorted(unknown)}")
    if frame["operation_id"].nunique() < 2:
        raise ValueError("at least two operation_id values are required")

    splitter = GroupShuffleSplit(n_splits=1, test_size=args.test_size, random_state=args.seed)
    train_index, test_index = next(splitter.split(frame, groups=frame["operation_id"]))
    train = frame.iloc[train_index].copy()
    test = frame.iloc[test_index].copy()
    missing_train = set(LABEL_TO_ID) - set(train["attack_group"])
    if missing_train:
        raise ValueError(f"training split lacks classes: {sorted(missing_train)}")

    features = [column for column in frame.columns if column not in NEVER_FEATURES]
    leaked = [column for column in features if any(token in column.lower() for token in FORBIDDEN_TOKENS)]
    if leaked:
        raise ValueError(f"possible leakage columns: {leaked}")

    x_train = train[features]
    x_test = test[features]
    y_train = train["attack_group"].map(LABEL_TO_ID)
    y_test = test["attack_group"].map(LABEL_TO_ID)
    categorical = [column for column in features if x_train[column].dtype == "object"]
    numeric = [column for column in features if column not in categorical]

    preprocessing = ColumnTransformer([
        ("categorical", OneHotEncoder(handle_unknown="ignore"), categorical),
        ("numeric", "passthrough", numeric),
    ])
    model = XGBClassifier(
        n_estimators=args.n_estimators,
        max_depth=5,
        learning_rate=0.05,
        subsample=0.8,
        colsample_bytree=0.8,
        objective="multi:softprob",
        num_class=len(LABEL_TO_ID),
        eval_metric="mlogloss",
        tree_method="hist",
        random_state=args.seed,
        n_jobs=-1,
    )
    pipeline = Pipeline([("preprocess", preprocessing), ("model", model)])
    weights = compute_sample_weight(class_weight="balanced", y=y_train)
    pipeline.fit(x_train, y_train, model__sample_weight=weights)

    predicted = pipeline.predict(x_test)
    probabilities = pipeline.predict_proba(x_test)
    label_ids = [0, 1, 2]
    report = classification_report(
        y_test, predicted, labels=label_ids,
        target_names=[ID_TO_LABEL[value] for value in label_ids],
        output_dict=True, zero_division=0,
    )
    matrix = confusion_matrix(y_test, predicted, labels=label_ids)

    args.output_dir.mkdir(parents=True, exist_ok=True)
    model_path = args.output_dir / "wazuh_multisource_xgboost.joblib"
    bundle = {
        "pipeline": pipeline,
        "feature_columns": features,
        "label_to_id": LABEL_TO_ID,
        "id_to_label": ID_TO_LABEL,
        "created_at": datetime.now(timezone.utc).isoformat(),
    }
    joblib.dump(bundle, model_path)
    (args.output_dir / "metrics.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    pd.DataFrame(
        matrix,
        index=[f"actual_{ID_TO_LABEL[value]}" for value in label_ids],
        columns=[f"predicted_{ID_TO_LABEL[value]}" for value in label_ids],
    ).to_csv(args.output_dir / "confusion_matrix.csv")

    result_columns = [column for column in ("event_id", "operation_id", "attack_type", "attack_group") if column in test]
    result = test[result_columns].copy()
    result["predicted_group"] = [ID_TO_LABEL[int(value)] for value in predicted]
    for class_id, class_name in ID_TO_LABEL.items():
        result[f"probability_{class_name}"] = probabilities[:, class_id]
    result.to_csv(args.output_dir / "test_predictions.csv", index=False)

    print(json.dumps({
        "train_rows": len(train),
        "test_rows": len(test),
        "train_operations": int(train["operation_id"].nunique()),
        "test_operations": int(test["operation_id"].nunique()),
        "accuracy": report["accuracy"],
        "macro_f1": report["macro avg"]["f1-score"],
        "post_compromise_recall": report["Post_Compromise"]["recall"],
        "model": str(model_path.resolve()),
    }, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
