#!/usr/bin/env python3
"""Export a time/agent-bounded subset of Wazuh alerts.json."""

from __future__ import annotations

import argparse
import json
from datetime import datetime, timezone
from pathlib import Path


def parse_time(value: str) -> datetime:
    return datetime.fromisoformat(value.replace("Z", "+00:00")).astimezone(timezone.utc)


def nested(item: dict, *keys: str):
    value = item
    for key in keys:
        if not isinstance(value, dict):
            return None
        value = value.get(key)
    return value


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--agent")
    parser.add_argument("--since", required=True)
    parser.add_argument("--until")
    args = parser.parse_args()

    since = parse_time(args.since)
    until = parse_time(args.until) if args.until else datetime.now(timezone.utc)
    if since >= until:
        parser.error("--since must be earlier than --until")

    written = 0
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.input.open("r", encoding="utf-8") as source, args.output.open("w", encoding="utf-8") as target:
        for line_number, line in enumerate(source, 1):
            if not line.strip():
                continue
            try:
                item = json.loads(line)
                timestamp = parse_time(str(item["timestamp"]))
            except (json.JSONDecodeError, KeyError, ValueError) as exc:
                raise ValueError(f"invalid alert at line {line_number}: {exc}") from exc
            if not since <= timestamp <= until:
                continue
            if args.agent and nested(item, "agent", "name") != args.agent:
                continue
            target.write(json.dumps(item, ensure_ascii=False) + "\n")
            written += 1
    print(json.dumps({"alerts_written": written, "output": str(args.output.resolve())}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

