#!/usr/bin/env bash
set -Eeuo pipefail

if [[ ${EUID} -ne 0 ]]; then
  echo "Run with sudo." >&2
  exit 1
fi

rm -f /etc/audit/rules.d/wazuh-lab.rules
rm -f /etc/suricata/rules/wazuh-lab.rules
augenrules --load
systemctl restart auditd
systemctl restart suricata
echo "Lab-specific Auditd and Suricata rule files removed."

