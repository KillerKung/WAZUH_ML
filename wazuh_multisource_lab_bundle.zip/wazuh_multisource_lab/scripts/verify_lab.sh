#!/usr/bin/env bash
set -u

failed=0
check_service() {
  local service=$1
  if systemctl is-active --quiet "$service"; then
    echo "OK service: $service"
  else
    echo "FAIL service: $service" >&2
    failed=1
  fi
}

check_file() {
  local file=$1
  if [[ -r "$file" ]]; then
    echo "OK file: $file"
  else
    echo "FAIL file: $file" >&2
    failed=1
  fi
}

check_service wazuh-agent
check_service suricata
check_service auditd
check_file /var/log/suricata/eve.json
check_file /var/log/audit/audit.log
check_file /etc/audit/rules.d/wazuh-lab.rules

if grep -q '/var/log/suricata/eve.json' /var/ossec/etc/ossec.conf; then
  echo "OK Wazuh reads Suricata EVE"
else
  echo "FAIL Wazuh Suricata localfile missing" >&2
  failed=1
fi
if grep -q '/var/log/audit/audit.log' /var/ossec/etc/ossec.conf; then
  echo "OK Wazuh reads Auditd"
else
  echo "FAIL Wazuh Auditd localfile missing" >&2
  failed=1
fi

exit "$failed"

