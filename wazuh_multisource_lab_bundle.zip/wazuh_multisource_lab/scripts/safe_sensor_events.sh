#!/usr/bin/env bash
set -Eeuo pipefail

operation_id=""
while [[ $# -gt 0 ]]; do
  case "$1" in
    --operation-id) operation_id=${2:-}; shift 2 ;;
    *) echo "Usage: sudo bash $0 --operation-id op-001" >&2; exit 2 ;;
  esac
done
if [[ ${EUID} -ne 0 || -z "$operation_id" ]]; then
  echo "Usage: sudo bash $0 --operation-id op-001" >&2
  exit 2
fi
if [[ ! "$operation_id" =~ ^[A-Za-z0-9._-]+$ ]]; then
  echo "Invalid operation id" >&2
  exit 2
fi

run_dir="/opt/wazuh-lab/runs/$operation_id"
install -d -m 0755 "$run_dir"
date --iso-8601=seconds > "$run_dir/start.txt"
id > "$run_dir/identity.txt"
printf 'authorized lab change\n' > "$run_dir/audit-file.txt"
chmod 0640 "$run_dir/audit-file.txt"
cp "$run_dir/audit-file.txt" "$run_dir/audit-file-copy.txt"
rm -f "$run_dir/audit-file-copy.txt"
date --iso-8601=seconds > "$run_dir/end.txt"

echo "Safe Auditd events generated in $run_dir"

