#!/usr/bin/env bash
set -Eeuo pipefail

manager=""
interface=""
home_net=""
agent_name="lab-sensor-01"

usage() {
  echo "Usage: sudo bash $0 --manager IP --interface IFACE --home-net CIDR [--agent-name NAME]"
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --manager) manager=${2:-}; shift 2 ;;
    --interface) interface=${2:-}; shift 2 ;;
    --home-net) home_net=${2:-}; shift 2 ;;
    --agent-name) agent_name=${2:-}; shift 2 ;;
    -h|--help) usage; exit 0 ;;
    *) echo "Unknown option: $1" >&2; usage; exit 2 ;;
  esac
done

if [[ ${EUID} -ne 0 ]]; then
  echo "Run with sudo." >&2
  exit 1
fi
if [[ -z "$manager" || -z "$interface" || -z "$home_net" ]]; then
  usage >&2
  exit 2
fi
if ! ip link show "$interface" >/dev/null 2>&1; then
  echo "Network interface not found: $interface" >&2
  exit 1
fi

script_dir=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
lab_root=$(cd -- "$script_dir/.." && pwd)

export DEBIAN_FRONTEND=noninteractive
apt-get update
apt-get install -y curl gnupg apt-transport-https ca-certificates software-properties-common jq auditd audispd-plugins python3

install -d -m 0755 /usr/share/keyrings
rm -f /usr/share/keyrings/wazuh.gpg
curl --fail --silent --show-error https://packages.wazuh.com/key/GPG-KEY-WAZUH \
  | gpg --no-default-keyring --keyring gnupg-ring:/usr/share/keyrings/wazuh.gpg --import
chmod 0644 /usr/share/keyrings/wazuh.gpg
echo 'deb [signed-by=/usr/share/keyrings/wazuh.gpg] https://packages.wazuh.com/4.x/apt/ stable main' \
  > /etc/apt/sources.list.d/wazuh.list
apt-get update
WAZUH_MANAGER="$manager" WAZUH_AGENT_NAME="$agent_name" apt-get install -y wazuh-agent

add-apt-repository -y ppa:oisf/suricata-stable
apt-get update
apt-get install -y suricata suricata-update

install -d -m 0755 /etc/suricata/rules /opt/wazuh-lab/runs
install -m 0644 "$lab_root/configs/suricata/local.rules" /etc/suricata/rules/wazuh-lab.rules
install -m 0640 "$lab_root/configs/auditd/wazuh-lab.rules" /etc/audit/rules.d/wazuh-lab.rules

python3 "$lab_root/tools/configure_sensor.py" \
  --ossec /var/ossec/etc/ossec.conf \
  --suricata /etc/suricata/suricata.yaml \
  --interface "$interface" \
  --home-net "$home_net"

augenrules --load
suricata-update || true
suricata -T -c /etc/suricata/suricata.yaml

systemctl daemon-reload
systemctl enable --now auditd
systemctl enable --now suricata
systemctl enable --now wazuh-agent
systemctl restart auditd
systemctl restart suricata
systemctl restart wazuh-agent

echo "Sensor ready: agent=$agent_name manager=$manager interface=$interface HOME_NET=$home_net"

