#!/usr/bin/env bash
set -Eeuo pipefail

sensor=""
operation_id=""
while [[ $# -gt 0 ]]; do
  case "$1" in
    --sensor) sensor=${2:-}; shift 2 ;;
    --operation-id) operation_id=${2:-}; shift 2 ;;
    *) echo "Usage: bash $0 --sensor IP --operation-id op-001" >&2; exit 2 ;;
  esac
done
if [[ -z "$sensor" || -z "$operation_id" ]]; then
  echo "Usage: bash $0 --sensor IP --operation-id op-001" >&2
  exit 2
fi

ping -c 5 "$sensor" || true
for path in lab-scan lab-admin-check lab-health; do
  curl --max-time 3 --silent --output /dev/null \
    "http://$sensor/$path?operation=$operation_id" || true
done
for _ in 1 2 3 4 5; do
  timeout 2 bash -c "</dev/tcp/$sensor/22" >/dev/null 2>&1 || true
done

echo "Safe network traffic completed for $operation_id"

