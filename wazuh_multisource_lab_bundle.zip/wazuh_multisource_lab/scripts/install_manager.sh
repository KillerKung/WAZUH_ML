#!/usr/bin/env bash
set -Eeuo pipefail

if [[ ${EUID} -ne 0 ]]; then
  echo "Run with sudo: sudo bash $0" >&2
  exit 1
fi

if ! grep -qiE 'ubuntu|debian' /etc/os-release; then
  echo "This lab installer targets Ubuntu/Debian. Use the official Wazuh guide for other systems." >&2
  exit 1
fi

available_kb=$(awk '/MemAvailable/ {print $2}' /proc/meminfo)
if (( available_kb < 6500000 )); then
  echo "Warning: Wazuh all-in-one is recommended to have at least 8 GiB RAM." >&2
fi

apt-get update
apt-get install -y curl ca-certificates

work_dir=$(mktemp -d /tmp/wazuh-lab-manager.XXXXXX)
trap 'rm -rf "$work_dir"' EXIT
cd "$work_dir"
curl --fail --show-error --location --remote-name https://packages.wazuh.com/4.14/wazuh-install.sh
bash ./wazuh-install.sh -a

echo
echo "Wazuh all-in-one installation completed. Save the credentials printed above."
echo "Dashboard: https://$(hostname -I | awk '{print $1}')"

