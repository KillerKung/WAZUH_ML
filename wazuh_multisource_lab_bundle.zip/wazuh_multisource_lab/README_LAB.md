# Wazuh + Suricata + Auditd ML Lab

ชุด Lab สำหรับโครงงาน **Wazuh Alert Prioritization & Noise Reduction** โดยเก็บข้อมูลจาก Wazuh, Suricata และ Auditd แล้วนำไป Normalize, Correlate และฝึก XGBoost แบบ 3 Classes:

- `Normal` (0)
- `Pre_Compromise` (1): Network scan, Web scan, Brute force
- `Post_Compromise` (2): Compromised login, Web shell, Privilege escalation

> Lab นี้ใช้เฉพาะเครื่องที่คุณเป็นเจ้าของหรือได้รับอนุญาต ชุดทดสอบที่ให้มาไม่ติดตั้ง Web shell และไม่ยกระดับสิทธิ์จริง เหตุการณ์อันตรายใช้ Log จำลองหรือกิจกรรมไฟล์/Process ที่ไม่ทำลายระบบ

## 1. โครงสร้าง Lab

| เครื่อง | ระบบ | CPU/RAM ขั้นต่ำ | ตัวอย่าง IP | หน้าที่ |
|---|---|---:|---|---|
| Manager | Ubuntu 22.04/24.04 | 4 vCPU / 8 GB | `192.168.56.10` | Wazuh Server, Indexer, Dashboard |
| Sensor | Ubuntu 22.04/24.04 | 2 vCPU / 4 GB | `192.168.56.20` | Wazuh Agent, Suricata, Auditd, SSH/Web target |
| Tester | Linux/Kali | 2 vCPU / 2 GB | `192.168.56.30` | สร้าง Traffic ทดสอบที่ได้รับอนุญาต |

แนะนำเครือข่าย Host-only หรือ Internal Network เพื่อไม่ให้ Traffic ทดสอบออกสู่ระบบจริง

```text
Tester ──traffic──> Sensor
                    ├── Suricata eve.json ─┐
                    ├── Auditd audit.log ──┼──> Wazuh Agent
                    └── auth/app logs ─────┘         │
                                                     v
                                             Wazuh Manager
                                                     │
                                                     v
                                             alerts.json → ML
```

## 2. เตรียม Manager

บนเครื่อง Manager:

```bash
cd wazuh_multisource_lab
sudo bash scripts/install_manager.sh
```

สคริปต์ใช้ Wazuh installation assistant สายรุ่น `4.14` แบบ all-in-one ตามเอกสารทางการ เมื่อเสร็จให้จด:

- URL ของ Dashboard
- Username/Password
- IP ของ Manager

พอร์ตที่เครือข่าย Lab ต้องอนุญาตอย่างน้อย:

| Port | Protocol | การใช้งาน |
|---:|---|---|
| 1514 | TCP | Agent events |
| 1515 | TCP | Agent enrollment |
| 443 | TCP | Dashboard |

## 3. เตรียม Sensor

ตรวจชื่อ Network interface ก่อน:

```bash
ip -br address
```

จากนั้นรัน โดยเปลี่ยน IP และ Interface ให้ตรงกับเครื่อง:

```bash
cd wazuh_multisource_lab
sudo bash scripts/install_sensor.sh \
  --manager 192.168.56.10 \
  --interface enp0s8 \
  --home-net 192.168.56.0/24 \
  --agent-name lab-sensor-01
```

สคริปต์จะ:

1. ติดตั้งและลงทะเบียน Wazuh Agent
2. ติดตั้ง Suricata และเปิด `eve.json`
3. ติดตั้ง Auditd และกฎ Lab
4. ให้ Wazuh Agent อ่าน `/var/log/suricata/eve.json`
5. ให้ Wazuh Agentอ่าน `/var/log/audit/audit.log`
6. สร้าง `/opt/wazuh-lab` สำหรับการทดลองที่ไม่กระทบระบบ

สคริปต์จะสำรอง `/var/ossec/etc/ossec.conf` ก่อนแก้ และไม่ใส่ Audit immutable flag (`-e 2`) จึงถอดกฎได้ภายหลัง

## 4. ตรวจสถานะ

บน Sensor:

```bash
sudo bash scripts/verify_lab.sh
```

ตรวจเองเพิ่มเติม:

```bash
sudo systemctl status wazuh-agent --no-pager
sudo systemctl status suricata --no-pager
sudo systemctl status auditd --no-pager
sudo tail -f /var/log/suricata/eve.json
sudo tail -f /var/log/audit/audit.log
```

บน Manager:

```bash
sudo /var/ossec/bin/agent_control -lc
sudo tail -f /var/ossec/logs/alerts/alerts.json
```

ใน Dashboard ใช้ Filter:

```text
agent.name: lab-sensor-01
rule.groups: suricata
```

## 5. รันทดสอบอย่างปลอดภัย

### 5.1 ทดสอบ Host/Auditd บน Sensor

```bash
sudo bash scripts/safe_sensor_events.sh --operation-id op-001
```

กิจกรรมที่เกิดขึ้นมีเพียงสร้าง/แก้ permission/ลบไฟล์ใน `/opt/wazuh-lab/runs/op-001` และเรียกคำสั่งทั่วไป เพื่อให้ Auditd สร้าง Process/File events

### 5.2 ทดสอบ Network จาก Tester

```bash
bash scripts/safe_tester_traffic.sh \
  --sensor 192.168.56.20 \
  --operation-id op-001
```

กิจกรรมประกอบด้วย ICMP, HTTP path สำหรับ Lab และ TCP connect ไปยังพอร์ต 22 จำนวนจำกัด ไม่ทำ Password guessing

### 5.3 สร้าง Log จำลองครบ Attack Chain

กรณีต้องการ `Compromised_Login`, `Web_Shell` และ `Privilege_Escalation` โดยไม่โจมตีจริง:

```bash
python3 tools/generate_multisource_events.py \
  --operation-id op-001 \
  --output data/events.jsonl \
  --labels data/labels.jsonl

sudo install -m 0644 data/events.jsonl /opt/wazuh-lab/events.jsonl
```

ให้ Wazuh อ่านเฉพาะ `data/events.jsonl` ห้ามอ่าน `data/labels.jsonl`

## 6. เก็บ Alert จาก Manager

ไฟล์ Alert หลักอยู่ที่:

```text
/var/ossec/logs/alerts/alerts.json
```

คัดลอกเฉพาะช่วง Lab และ Agent ที่ต้องการ:

```bash
python3 tools/export_wazuh_alerts.py \
  --input /var/ossec/logs/alerts/alerts.json \
  --output data/alerts_lab.jsonl \
  --agent lab-sensor-01 \
  --since 2026-08-20T00:00:00Z
```

## 7. Normalize ข้อมูลหลาย Source

```bash
python3 tools/normalize_multisource.py \
  --alerts data/alerts_lab.jsonl \
  --output data/normalized.csv
```

ผลลัพธ์มี Common Schema และ Behavioral Features เช่น:

```text
source_system
event_type
rule_level
event_action
protocol
source_port
destination_port
audit_event_present
process_present
file_change
privilege_change
network_alerts_previous_5m
audit_events_previous_5m
failed_logins_previous_10m
cross_source_count_previous_10m
chain_length_previous_30m
```

ข้อมูลอย่าง `source_ip`, `username`, `audit_session_id` และ `raw_log` ใช้ Correlation ภายใน แต่ไม่ Export เป็น ML Feature

## 8. ตรวจ Dataset

```bash
python3 tools/validate_normalized.py data/normalized.csv
```

ตัวตรวจจะยืนยันว่า:

- มี Common Schema ขั้นต่ำ
- ไม่มีคอลัมน์ Marker/Provenance/Session/Raw log หลุดออกมา
- ค่า Numeric ไม่มี Infinity
- ถ้ามี Label ต้องเป็น `Normal`, `Pre_Compromise`, `Post_Compromise`

## 9. ลำดับการเก็บข้อมูลสำหรับ ML

ควรเก็บอย่างน้อย 20–30 Operations ต่อกลุ่ม และเปลี่ยนเวลา/จำนวน Event/เครื่องเป้าหมาย/ความถี่ในแต่ละรอบ:

```text
Normal
Pre_Compromise
Post_Compromise
```

แบ่ง Train/Test ด้วย `operation_id` เท่านั้น ห้ามสุ่ม Alert จาก Operation เดียวกันปนกัน

ติดตั้งแพ็กเกจและฝึกโมเดล:

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements-lab.txt

python3 tools/train_lifecycle_model.py \
  --dataset data/normalized.csv \
  --output-dir artifacts
```

ทำนาย Alert ชุดใหม่:

```bash
python3 tools/predict_lifecycle.py \
  --model artifacts/wazuh_multisource_xgboost.joblib \
  --dataset data/new_normalized.csv \
  --output predictions/prioritized_alerts.csv
```

คะแนนจากข้อมูลจำลองอาจสูงมากหรือถึง 100% เพราะรูปแบบเหตุการณ์ถูกสร้างอย่างเป็นระบบ ตัวเลขนี้ใช้ตรวจว่า Pipeline ทำงานครบวงจรเท่านั้น ห้ามใช้เป็นผลการวิจัย ต้องประเมินใหม่ด้วย Alert จริง หลาย Operations และรูปแบบ Noise ที่หลากหลาย

## 10. ปิดหรือถอดกฎ Lab

บน Sensor:

```bash
sudo bash scripts/remove_lab_rules.sh
```

คำสั่งนี้ถอดเฉพาะไฟล์กฎที่ชุด Lab สร้าง และไม่ลบ Wazuh, Suricata หรือ Auditd

## เอกสารอ้างอิงทางการ

- Wazuh Quickstart: https://documentation.wazuh.com/current/quickstart.html
- Wazuh + Suricata: https://documentation.wazuh.com/current/proof-of-concept-guide/integrate-network-ids-suricata.html
- Wazuh Audit configuration: https://documentation.wazuh.com/current/user-manual/capabilities/system-calls-monitoring/audit-configuration.html
- Wazuh Agent Linux: https://documentation.wazuh.com/current/installation-guide/wazuh-agent/wazuh-agent-package-linux.html
- Suricata EVE JSON: https://docs.suricata.io/en/latest/output/eve/eve-json-output.html
