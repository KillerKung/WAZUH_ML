# wazuh_ssh_bruteforce_v2_20260825

Dataset จาก Kali → Ubuntu lab ที่ได้รับอนุญาต ใช้ Wazuh alert และ generator ledger เป็น ground truth

## ใช้ไฟล์ไหน

- `train_windows.jsonl` และ `test_windows.jsonl`: แนะนำสำหรับเทรน/ประเมินโมเดลตรวจจับ Brute Force
- `train_events.jsonl` และ `test_events.jsonl`: log รายเหตุการณ์สำหรับตรวจสอบย้อนหลัง
- `runs.jsonl`: รายการ acquisition run และ coverage
- `manifest.json`: สรุปจำนวน, class distribution และ leakage checks

แบ่ง Train/Test ด้วย `run_id` ทั้งรอบ จึงไม่มี log จากรอบเดียวกันหลุดไปอยู่ทั้งสองชุด
ไม่ควรใช้ `label`, `label_id`, `scenario`, `split`, `run_id`, IP หรือ raw log เป็น feature

Accepted runs: 25 | Events: 911 | Windows: 284
