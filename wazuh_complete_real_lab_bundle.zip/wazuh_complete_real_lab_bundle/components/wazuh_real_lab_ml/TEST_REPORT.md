# Verification report

Tested on 2026-08-24 with Python 3.12 and the exact dependency versions in `requirements.txt`.

## Checks completed

- All Python files passed `py_compile`.
- `run_smoke_test.sh` passed `bash -n`.
- A clean virtual environment installed every pinned dependency.
- End-to-end smoke test completed: generator → rule router → validator → grouped training → prediction.
- Synthetic input: 540 alerts from 30 independent operations.
- Rule decisions: 360 aggregate, 60 known noise, 30 critical, 90 ML candidates.
- Training candidates: 30 Safe, 30 Suspicious, 30 Dangerous.
- No Dangerous row was routed to known noise or aggregation.
- Train, validation, and test splits were separated by `operation_id` and each contained all classes.
- Model bundle and prediction CSV were produced successfully.

The smoke dataset is deliberately easy. Its scores verify the software path only and must not be reported as model-performance evidence for the real lab.
