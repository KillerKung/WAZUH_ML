#!/usr/bin/env bash
set -euo pipefail

python3 make_smoke_dataset.py --output-dir smoke_data
python3 rule_router.py \
  --dataset smoke_data/labeled.csv \
  --config configs/rule_config.json \
  --output-dir smoke_data/routed
python3 validate_training_data.py \
  --dataset smoke_data/routed/ml_candidates.csv \
  --feature-config configs/feature_config.json \
  --profile hybrid
python3 train_xgboost.py \
  --dataset smoke_data/routed/ml_candidates.csv \
  --feature-config configs/feature_config.json \
  --profile hybrid \
  --output-dir smoke_artifacts \
  --n-estimators 40
python3 predict.py \
  --model smoke_artifacts/wazuh_xgboost.joblib \
  --dataset smoke_data/routed/ml_candidates.csv \
  --output smoke_artifacts/all_predictions.csv
