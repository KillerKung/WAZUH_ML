#!/usr/bin/env python3
"""Score ML-candidate alerts with a trained bundle and assign queue priority."""

from __future__ import annotations

import argparse
from pathlib import Path

import joblib
import numpy as np
import pandas as pd


def apply_threshold(probabilities: np.ndarray, dangerous_id: int, threshold: float) -> np.ndarray:
    predicted = probabilities.argmax(axis=1)
    predicted[probabilities[:, dangerous_id] >= threshold] = dangerous_id
    return predicted


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--model", type=Path, required=True)
    parser.add_argument("--dataset", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()

    bundle = joblib.load(args.model)
    frame = pd.read_csv(args.dataset)
    features = list(bundle["feature_columns"])
    missing = sorted(set(features) - set(frame.columns))
    if missing:
        raise ValueError(f"dataset missing model features: {missing}")

    probabilities = bundle["pipeline"].predict_proba(frame[features])
    label_to_id = {str(key): int(value) for key, value in bundle["label_to_id"].items()}
    id_to_label = {int(key): str(value) for key, value in bundle["id_to_label"].items()}
    dangerous_id = label_to_id["Dangerous"]
    threshold = float(bundle["dangerous_threshold"])
    predicted = apply_threshold(probabilities, dangerous_id, threshold)

    output = frame.copy()
    output["ml_class"] = [id_to_label[int(value)] for value in predicted]
    for class_id, class_name in sorted(id_to_label.items()):
        output[f"probability_{class_name}"] = probabilities[:, class_id]
    output["risk_score"] = (
        output["probability_Suspicious"] * 50.0 + output["probability_Dangerous"] * 100.0
    ).round(2)
    output["priority"] = output["ml_class"].map({
        "Dangerous": "P1",
        "Suspicious": "P2",
        "Safe": "P3",
    })
    output["dangerous_threshold"] = threshold
    args.output.parent.mkdir(parents=True, exist_ok=True)
    output.to_csv(args.output, index=False)
    print(f"wrote {len(output)} predictions to {args.output.resolve()}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
