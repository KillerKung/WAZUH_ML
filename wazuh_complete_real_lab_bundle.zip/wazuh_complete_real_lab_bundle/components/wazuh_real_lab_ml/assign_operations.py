#!/usr/bin/env python3
"""Assign operation_id from non-overlapping lab time windows, never labels."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import pandas as pd

from common import read_jsonl


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--dataset", type=Path, required=True)
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--unmatched-output", type=Path, required=True)
    args = parser.parse_args()

    frame = pd.read_csv(args.dataset)
    required = {"event_id", "timestamp", "agent_name"}
    missing = required - set(frame.columns)
    if missing:
        raise ValueError(f"dataset missing columns: {sorted(missing)}")
    frame["timestamp"] = pd.to_datetime(frame["timestamp"], utc=True, errors="coerce")
    if frame["timestamp"].isna().any():
        raise ValueError(f"{int(frame['timestamp'].isna().sum())} rows have invalid timestamps")

    operations = list(read_jsonl(args.manifest))
    seen_ids: set[str] = set()
    parsed: list[dict] = []
    for item in operations:
        missing_fields = {"operation_id", "start", "end", "agent_name"} - set(item)
        if missing_fields:
            raise ValueError(f"manifest entry missing: {sorted(missing_fields)}")
        operation_id = str(item["operation_id"])
        if operation_id in seen_ids:
            raise ValueError(f"duplicate operation_id: {operation_id}")
        seen_ids.add(operation_id)
        start = pd.to_datetime(item["start"], utc=True, errors="raise")
        end = pd.to_datetime(item["end"], utc=True, errors="raise")
        if start >= end:
            raise ValueError(f"operation {operation_id}: start must be before end")
        parsed.append({**item, "operation_id": operation_id, "start": start, "end": end})

    for left_index, left in enumerate(parsed):
        for right in parsed[left_index + 1:]:
            same_agent = str(left["agent_name"]) == str(right["agent_name"])
            overlaps = max(left["start"], right["start"]) <= min(left["end"], right["end"])
            if same_agent and overlaps:
                raise ValueError(
                    f"overlapping windows for {left['agent_name']}: "
                    f"{left['operation_id']} and {right['operation_id']}"
                )

    assigned = pd.Series(pd.NA, index=frame.index, dtype="object")
    scenario = pd.Series(pd.NA, index=frame.index, dtype="object")
    for item in parsed:
        mask = (
            frame["agent_name"].astype(str).eq(str(item["agent_name"]))
            & frame["timestamp"].between(item["start"], item["end"], inclusive="both")
        )
        assigned.loc[mask] = item["operation_id"]
        scenario.loc[mask] = str(item.get("scenario", "unknown"))

    frame["operation_id"] = assigned
    frame["operation_scenario"] = scenario
    matched = frame[frame["operation_id"].notna()].copy()
    unmatched = frame[frame["operation_id"].isna()].copy()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.unmatched_output.parent.mkdir(parents=True, exist_ok=True)
    matched.to_csv(args.output, index=False)
    unmatched.to_csv(args.unmatched_output, index=False)
    print(json.dumps({
        "input_rows": len(frame),
        "matched_rows": len(matched),
        "unmatched_rows": len(unmatched),
        "operations": int(matched["operation_id"].nunique()),
        "output": str(args.output.resolve()),
    }, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

