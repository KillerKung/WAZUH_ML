#!/usr/bin/env python3
"""Merge provenance-backed labels with normalized alerts by exact event_id."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import pandas as pd

from common import canonical_label, read_jsonl


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--dataset", type=Path, required=True)
    parser.add_argument("--labels", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--allow-unlabeled", action="store_true")
    args = parser.parse_args()

    frame = pd.read_csv(args.dataset, dtype={"event_id": "string"})
    if "event_id" not in frame:
        raise ValueError("dataset missing event_id")
    labels = pd.DataFrame(read_jsonl(args.labels))
    required = {"event_id", "class_3", "provenance"}
    missing = required - set(labels.columns)
    if missing:
        raise ValueError(f"labels missing columns: {sorted(missing)}")
    labels["event_id"] = labels["event_id"].astype("string")
    if labels["event_id"].duplicated().any():
        duplicates = labels.loc[labels["event_id"].duplicated(), "event_id"].head(10).tolist()
        raise ValueError(f"duplicate event_id values in labels: {duplicates}")
    labels["class_3"] = labels["class_3"].map(canonical_label)

    keep = [column for column in ("event_id", "class_3", "attack_type", "provenance", "reviewer") if column in labels]
    merged = frame.drop(columns=[column for column in ("class_3", "attack_type") if column in frame]).merge(
        labels[keep], on="event_id", how="left", validate="one_to_one"
    )
    unmatched = int(merged["class_3"].isna().sum())
    if unmatched and not args.allow_unlabeled:
        raise ValueError(f"{unmatched} rows have no exact provenance label")

    args.output.parent.mkdir(parents=True, exist_ok=True)
    merged.to_csv(args.output, index=False)
    print(json.dumps({
        "rows": len(merged),
        "unlabeled_rows": unmatched,
        "class_counts": merged["class_3"].value_counts(dropna=False).to_dict(),
        "output": str(args.output.resolve()),
    }, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

