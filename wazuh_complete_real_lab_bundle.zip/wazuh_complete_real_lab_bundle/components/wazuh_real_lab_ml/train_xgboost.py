#!/usr/bin/env python3
"""Train, calibrate a Dangerous threshold, and evaluate grouped XGBoost."""

from __future__ import annotations

import argparse
import json
from datetime import datetime, timezone
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.metrics import (
    accuracy_score,
    balanced_accuracy_score,
    classification_report,
    confusion_matrix,
    precision_recall_fscore_support,
)
from sklearn.model_selection import GroupShuffleSplit
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder
from sklearn.utils.class_weight import compute_sample_weight
from xgboost import XGBClassifier

from common import ID_TO_LABEL, LABEL_TO_ID, canonical_label, load_feature_profile


ALL_LABELS = [0, 1, 2]


def has_all_classes(values: pd.Series) -> bool:
    return set(values) == set(ALL_LABELS)


def grouped_three_way_split(
    frame: pd.DataFrame,
    labels: pd.Series,
    validation_size: float,
    test_size: float,
    seed: int,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, int]:
    if validation_size + test_size >= 1:
        raise ValueError("validation_size + test_size must be less than 1")
    groups = frame["operation_id"].astype(str)
    relative_validation = validation_size / (1 - test_size)
    for attempt_seed in range(seed, seed + 200):
        outer = GroupShuffleSplit(n_splits=1, test_size=test_size, random_state=attempt_seed)
        train_val_index, test_index = next(outer.split(frame, labels, groups))
        train_val = frame.iloc[train_val_index]
        train_val_labels = labels.iloc[train_val_index]
        inner = GroupShuffleSplit(n_splits=1, test_size=relative_validation, random_state=attempt_seed + 10000)
        train_local, validation_local = next(inner.split(train_val, train_val_labels, train_val["operation_id"]))
        train_index = train_val_index[train_local]
        validation_index = train_val_index[validation_local]
        if all(has_all_classes(labels.iloc[index]) for index in (train_index, validation_index, test_index)):
            return train_index, validation_index, test_index, attempt_seed
    raise ValueError(
        "could not create operation-separated train/validation/test splits containing all classes; "
        "collect more operations per class"
    )


def apply_dangerous_threshold(probabilities: np.ndarray, threshold: float) -> np.ndarray:
    predicted = probabilities.argmax(axis=1)
    predicted[probabilities[:, LABEL_TO_ID["Dangerous"]] >= threshold] = LABEL_TO_ID["Dangerous"]
    return predicted


def tune_threshold(y_true: pd.Series, probabilities: np.ndarray, minimum_precision: float) -> dict[str, float]:
    candidates: list[dict[str, float]] = []
    for threshold in np.linspace(0.05, 0.95, 91):
        predicted_dangerous = probabilities[:, 2] >= threshold
        actual_dangerous = y_true.to_numpy() == 2
        precision, recall, f1, _ = precision_recall_fscore_support(
            actual_dangerous, predicted_dangerous, average="binary", zero_division=0
        )
        candidates.append({
            "threshold": float(threshold),
            "precision": float(precision),
            "recall": float(recall),
            "f1": float(f1),
        })
    feasible = [item for item in candidates if item["precision"] >= minimum_precision]
    pool = feasible or candidates
    return max(pool, key=lambda item: (item["recall"], item["f1"], item["precision"], item["threshold"]))


def evaluate(y_true: pd.Series, probabilities: np.ndarray, threshold: float) -> tuple[dict, np.ndarray, np.ndarray]:
    predicted = apply_dangerous_threshold(probabilities, threshold)
    report = classification_report(
        y_true, predicted, labels=ALL_LABELS,
        target_names=[ID_TO_LABEL[value] for value in ALL_LABELS],
        output_dict=True, zero_division=0,
    )
    metrics = {
        "accuracy": float(accuracy_score(y_true, predicted)),
        "balanced_accuracy": float(balanced_accuracy_score(y_true, predicted)),
        "macro_f1": float(report["macro avg"]["f1-score"]),
        "dangerous_precision": float(report["Dangerous"]["precision"]),
        "dangerous_recall": float(report["Dangerous"]["recall"]),
        "dangerous_f1": float(report["Dangerous"]["f1-score"]),
        "dangerous_as_safe": int(((y_true.to_numpy() == 2) & (predicted == 0)).sum()),
        "classification_report": report,
    }
    matrix = confusion_matrix(y_true, predicted, labels=ALL_LABELS)
    return metrics, matrix, predicted


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--dataset", type=Path, required=True)
    parser.add_argument("--feature-config", type=Path, required=True)
    parser.add_argument("--profile", default="hybrid")
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--validation-size", type=float, default=0.15)
    parser.add_argument("--test-size", type=float, default=0.15)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--n-estimators", type=int, default=300)
    parser.add_argument("--max-depth", type=int, default=5)
    parser.add_argument("--learning-rate", type=float, default=0.05)
    parser.add_argument("--min-dangerous-precision", type=float, default=0.50)
    args = parser.parse_args()

    frame = pd.read_csv(args.dataset)
    required = {"event_id", "operation_id", "class_3"}
    missing = required - set(frame.columns)
    if missing:
        raise ValueError(f"dataset missing columns: {sorted(missing)}")
    frame = frame.dropna(subset=["class_3", "operation_id"]).copy()
    frame["class_3"] = frame["class_3"].map(canonical_label)
    categorical, numeric = load_feature_profile(args.feature_config, args.profile)
    features = categorical + numeric
    missing_features = set(features) - set(frame.columns)
    if missing_features:
        raise ValueError(f"dataset missing configured features: {sorted(missing_features)}")

    labels = frame["class_3"].map(LABEL_TO_ID)
    train_index, validation_index, test_index, split_seed = grouped_three_way_split(
        frame, labels, args.validation_size, args.test_size, args.seed
    )
    train = frame.iloc[train_index].copy()
    validation = frame.iloc[validation_index].copy()
    test = frame.iloc[test_index].copy()
    y_train = labels.iloc[train_index]
    y_validation = labels.iloc[validation_index]
    y_test = labels.iloc[test_index]

    preprocessing = ColumnTransformer([
        ("categorical", Pipeline([
            ("impute", SimpleImputer(strategy="most_frequent")),
            ("encode", OneHotEncoder(handle_unknown="ignore")),
        ]), categorical),
        ("numeric", Pipeline([
            ("impute", SimpleImputer(strategy="median")),
        ]), numeric),
    ])
    classifier = XGBClassifier(
        n_estimators=args.n_estimators,
        max_depth=args.max_depth,
        learning_rate=args.learning_rate,
        subsample=0.8,
        colsample_bytree=0.8,
        objective="multi:softprob",
        num_class=3,
        eval_metric="mlogloss",
        tree_method="hist",
        random_state=args.seed,
        n_jobs=-1,
    )
    pipeline = Pipeline([("preprocess", preprocessing), ("model", classifier)])
    weights = compute_sample_weight(class_weight="balanced", y=y_train)
    pipeline.fit(train[features], y_train, model__sample_weight=weights)

    validation_probabilities = pipeline.predict_proba(validation[features])
    threshold_result = tune_threshold(y_validation, validation_probabilities, args.min_dangerous_precision)
    threshold = threshold_result["threshold"]
    validation_metrics, validation_matrix, _ = evaluate(y_validation, validation_probabilities, threshold)
    test_probabilities = pipeline.predict_proba(test[features])
    test_metrics, test_matrix, test_predicted = evaluate(y_test, test_probabilities, threshold)

    args.output_dir.mkdir(parents=True, exist_ok=True)
    bundle = {
        "pipeline": pipeline,
        "feature_columns": features,
        "categorical_features": categorical,
        "numeric_features": numeric,
        "feature_profile": args.profile,
        "label_to_id": LABEL_TO_ID,
        "id_to_label": ID_TO_LABEL,
        "dangerous_threshold": threshold,
        "created_at": datetime.now(timezone.utc).isoformat(),
    }
    model_path = args.output_dir / "wazuh_xgboost.joblib"
    joblib.dump(bundle, model_path)

    metric_output = {
        "feature_profile": args.profile,
        "threshold_tuning": threshold_result,
        "validation": validation_metrics,
        "test": test_metrics,
        "rows": {"train": len(train), "validation": len(validation), "test": len(test)},
    }
    (args.output_dir / "metrics.json").write_text(json.dumps(metric_output, indent=2), encoding="utf-8")

    def save_matrix(matrix: np.ndarray, name: str) -> None:
        pd.DataFrame(
            matrix,
            index=[f"actual_{ID_TO_LABEL[value]}" for value in ALL_LABELS],
            columns=[f"predicted_{ID_TO_LABEL[value]}" for value in ALL_LABELS],
        ).to_csv(args.output_dir / name)

    save_matrix(validation_matrix, "confusion_matrix_validation.csv")
    save_matrix(test_matrix, "confusion_matrix_test.csv")

    predictions = test[[column for column in ("event_id", "operation_id", "attack_type", "class_3") if column in test]].copy()
    predictions["predicted_class"] = [ID_TO_LABEL[int(value)] for value in test_predicted]
    for class_id, class_name in ID_TO_LABEL.items():
        predictions[f"probability_{class_name}"] = test_probabilities[:, class_id]
    predictions.to_csv(args.output_dir / "test_predictions.csv", index=False)

    feature_names = pipeline.named_steps["preprocess"].get_feature_names_out()
    importance = pipeline.named_steps["model"].feature_importances_
    pd.DataFrame({"feature": feature_names, "importance": importance}).sort_values(
        "importance", ascending=False
    ).to_csv(args.output_dir / "feature_importance.csv", index=False)

    split_manifest = {
        "seed_used": split_seed,
        "train_operations": sorted(train["operation_id"].astype(str).unique().tolist()),
        "validation_operations": sorted(validation["operation_id"].astype(str).unique().tolist()),
        "test_operations": sorted(test["operation_id"].astype(str).unique().tolist()),
    }
    (args.output_dir / "split_manifest.json").write_text(json.dumps(split_manifest, indent=2), encoding="utf-8")
    print(json.dumps({
        "model": str(model_path.resolve()),
        "dangerous_threshold": threshold,
        "test_macro_f1": test_metrics["macro_f1"],
        "test_dangerous_recall": test_metrics["dangerous_recall"],
        "dangerous_as_safe": test_metrics["dangerous_as_safe"],
        "split_seed": split_seed,
    }, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

