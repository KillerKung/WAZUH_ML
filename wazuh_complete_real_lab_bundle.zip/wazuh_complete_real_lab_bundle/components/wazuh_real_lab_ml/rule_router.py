#!/usr/bin/env python3
"""Apply the explainable Rule-based first layer before ML training/inference."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import pandas as pd


def groups(value: object) -> set[str]:
    return {item.strip().lower() for item in str(value or "").replace(",", "|").split("|") if item.strip()}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--dataset", type=Path, required=True)
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    args = parser.parse_args()

    config = json.loads(args.config.read_text(encoding="utf-8"))
    frame = pd.read_csv(args.dataset)
    required = {"event_id", "operation_id", "timestamp", "event_action", "rule_level"}
    missing = required - set(frame.columns)
    if missing:
        raise ValueError(f"dataset missing columns: {sorted(missing)}")
    frame["timestamp"] = pd.to_datetime(frame["timestamp"], utc=True, errors="coerce")
    if frame["timestamp"].isna().any():
        raise ValueError("dataset contains invalid timestamps")
    frame["event_action"] = frame["event_action"].fillna("unknown").astype(str).str.lower()
    frame["rule_level"] = pd.to_numeric(frame["rule_level"], errors="coerce").fillna(0).astype(int)
    if "rule_groups" not in frame:
        frame["rule_groups"] = "unknown"

    window = int(config["aggregate_window_minutes"])
    frame["_time_bucket"] = frame["timestamp"].dt.floor(f"{window}min")
    group_columns = [column for column in ("operation_id", "agent_name", "source_system", "event_action", "_time_bucket") if column in frame]
    frame["rule_count"] = frame.groupby(group_columns, dropna=False)["event_id"].transform("size")

    critical_actions = {str(item).lower() for item in config["critical_actions"]}
    critical_groups = {str(item).lower() for item in config["critical_groups"]}
    noise_actions = {str(item).lower() for item in config["known_noise_actions"]}
    aggregate_actions = {str(item).lower() for item in config["aggregate_actions"]}
    critical_level = int(config["critical_min_level"])
    noise_max_level = int(config["known_noise_max_level"])
    aggregate_min = int(config["aggregate_min_count"])

    decisions: list[str] = []
    reasons: list[str] = []
    for row in frame.itertuples(index=False):
        row_groups = groups(row.rule_groups)
        if row.event_action in critical_actions or row.rule_level >= critical_level or row_groups & critical_groups:
            decisions.append("critical")
            reasons.append("explicit critical action/group or rule level")
        elif row.event_action in noise_actions and row.rule_level <= noise_max_level:
            decisions.append("known_noise")
            reasons.append("exact baseline allowlist action")
        elif row.event_action in aggregate_actions and row.rule_count >= aggregate_min:
            decisions.append("aggregate")
            reasons.append(f"repeated action count >= {aggregate_min} in {window}m")
        else:
            decisions.append("ml_candidate")
            reasons.append("ambiguous event requires behavioral model")

    frame["rule_decision"] = decisions
    frame["rule_reason"] = reasons
    frame = frame.drop(columns=["_time_bucket"])
    args.output_dir.mkdir(parents=True, exist_ok=True)
    names = {
        "all_routed": None,
        "ml_candidates": "ml_candidate",
        "known_noise": "known_noise",
        "aggregated": "aggregate",
        "critical": "critical",
    }
    for filename, decision in names.items():
        selected = frame if decision is None else frame[frame["rule_decision"] == decision]
        selected.to_csv(args.output_dir / f"{filename}.csv", index=False)

    report: dict[str, object] = {
        "input_alerts": len(frame),
        "decision_counts": frame["rule_decision"].value_counts().to_dict(),
        "ml_candidate_rate": float((frame["rule_decision"] == "ml_candidate").mean()),
        "rule_reduction_rate": float(1 - (frame["rule_decision"] == "ml_candidate").mean()),
    }
    if "class_3" in frame:
        report["decision_by_class"] = pd.crosstab(frame["rule_decision"], frame["class_3"]).to_dict()
        dangerous = frame[frame["class_3"] == "Dangerous"]
        report["dangerous_total"] = len(dangerous)
        report["dangerous_sent_to_ml"] = int((dangerous["rule_decision"] == "ml_candidate").sum())
        report["dangerous_direct_critical"] = int((dangerous["rule_decision"] == "critical").sum())
        report["dangerous_misrouted_noise"] = int(dangerous["rule_decision"].isin(["known_noise", "aggregate"]).sum())
    (args.output_dir / "rule_report.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps(report, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

