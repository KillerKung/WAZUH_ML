# Real-Lab ML Training Package

ชุดฝึกโมเดลสำหรับโครงงาน **Wazuh Alert Prioritization & Noise Reduction** ใช้กับข้อมูลจริงที่ผ่านการ Normalize จาก Wazuh + Suricata + Auditd แล้ว

แพ็กเกจนี้ให้ **Training pipeline** ไม่ได้ใส่โมเดลที่เทรนสำเร็จไว้ เพราะโมเดลใช้งานจริงต้องเรียนจาก Baseline, Attack operations และ Provenance labels ของ Lab ปลายทางเอง

สถาปัตยกรรม:

```text
alerts.json
→ Normalize
→ Assign operation_id
→ Merge provenance labels
→ Rule-based router
→ ML candidates
→ Grouped Train/Validation/Test
→ XGBoost
→ Threshold + Metrics + Model
```

## Classes

Canonical labels ตาม Guide:

```text
Safe = 0
Suspicious = 1
Dangerous = 2
```

ข้อมูลเดิมที่ใช้ชื่อ `Normal / Pre_Compromise / Post_Compromise` ใช้ได้เช่นกัน ระบบจะแปลงเป็น Canonical labels อัตโนมัติ

## Requirements

แนะนำ Python 3.10-3.12:

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

เวอร์ชันใน `requirements.txt` คือเวอร์ชันที่ใช้ทดสอบชุดนี้

## Input ที่ต้องเตรียม

### 1. Normalized CSV

สร้างจาก Lab Kit เดิม:

```bash
python3 ../wazuh_multisource_lab/tools/normalize_multisource.py \
  --alerts data/alerts_lab.jsonl \
  --output data/normalized.csv
```

ข้อมูลต้องมี `event_id`, `timestamp`, `agent_name`, `source_system` และ Feature จาก Wazuh/Suricata/Auditd

### 2. Operation manifest

หนึ่งรายการต่อหนึ่งรอบทดลอง:

```json
{"operation_id":"op-001","start":"2026-08-24T01:00:00Z","end":"2026-08-24T01:20:00Z","agent_name":"lab-sensor-01","scenario":"brute_force_chain"}
```

เวลาใช้เพียงกำหนดรอบทดลองเพื่อแบ่ง Train/Test ไม่ได้ใช้ตัดสิน Label

### 3. Provenance labels

```json
{"event_id":"1756000000.123","class_3":"Dangerous","attack_type":"Web_Shell","provenance":"audit session reconciled with operation log","reviewer":"student-1"}
```

Marker, attacker IP, username, session และ provenance ใช้สร้างเฉลยได้ แต่ห้ามเป็น ML Feature

## ขั้นตอนใช้งานจริง

### ขั้นที่ 1: กำหนด Operation

```bash
python3 assign_operations.py \
  --dataset data/normalized.csv \
  --manifest data/operations.jsonl \
  --output data/with_operations.csv \
  --unmatched-output data/unmatched.csv
```

ระบบจะหยุดถ้า Operation windows ซ้อนกันสำหรับ Agent เดียวกัน

### ขั้นที่ 2: เชื่อม Label

```bash
python3 merge_labels.py \
  --dataset data/with_operations.csv \
  --labels data/labels.jsonl \
  --output data/labeled.csv
```

ใช้ `event_id` แบบ one-to-one และไม่เดา Label จากเวลา

### ขั้นที่ 3: ผ่าน Rule-based Router

```bash
python3 rule_router.py \
  --dataset data/labeled.csv \
  --config configs/rule_config.json \
  --output-dir data/routed
```

ผลลัพธ์:

```text
all_routed.csv
ml_candidates.csv
known_noise.csv
aggregated.csv
critical.csv
rule_report.json
```

Raw rows ไม่ถูกลบ เพียงแยกเส้นทางเพื่อให้ตรวจสอบย้อนหลังได้

### ขั้นที่ 4: ตรวจ Dataset

```bash
python3 validate_training_data.py \
  --dataset data/routed/ml_candidates.csv \
  --feature-config configs/feature_config.json \
  --profile hybrid
```

### ขั้นที่ 5: Train

```bash
python3 train_xgboost.py \
  --dataset data/routed/ml_candidates.csv \
  --feature-config configs/feature_config.json \
  --profile hybrid \
  --output-dir artifacts/hybrid
```

ไฟล์ผลลัพธ์:

```text
wazuh_xgboost.joblib
metrics.json
confusion_matrix_test.csv
test_predictions.csv
feature_importance.csv
split_manifest.json
```

### ขั้นที่ 6: Predict ชุดใหม่

ข้อมูลใหม่ต้องผ่าน Normalize และ Rule Router ก่อน แล้วเลือกเฉพาะ `ml_candidate`:

```bash
python3 predict.py \
  --model artifacts/hybrid/wazuh_xgboost.joblib \
  --dataset data/new_ml_candidates.csv \
  --output predictions/prioritized.csv
```

## Feature profiles

`behavioral` ใช้ Feature พฤติกรรมเป็นหลัก เหมาะสำหรับตรวจว่าโมเดลเรียนรู้ Context จริงหรือไม่

`hybrid` เพิ่ม `event_action`, Rule groups, MITRE และ Rule level เหมาะเป็นโมเดลใช้งาน แต่ควรเปรียบเทียบกับ Behavioral model เพื่อดูว่าโมเดลไม่ได้จำ Rule อย่างเดียว

```bash
python3 train_xgboost.py ... --profile behavioral --output-dir artifacts/behavioral
python3 train_xgboost.py ... --profile hybrid --output-dir artifacts/hybrid
```

ใช้ Test operations ชุดเดียวกันเมื่อเปรียบเทียบโมเดล

## เกณฑ์ขั้นต่ำก่อนใช้จริง

- ทุก Split ต้องมีครบทั้ง 3 Classes
- Test ต้องเป็น Operations ที่โมเดลไม่เคยเห็น
- รายงาน Precision, Recall, F1, Macro F1 และ Confusion Matrix
- ตรวจ `Dangerous → Safe` False Negative ทุกครั้ง
- เก็บ Golden test set ที่ติด Label ด้วย Provenance
- เริ่ม Deploy แบบ Shadow mode ก่อน ห้ามให้โมเดลสั่ง Block อัตโนมัติทันที
- Metrics จาก `make_smoke_dataset.py` ใช้ตรวจโค้ดเท่านั้น ไม่ใช่ผลวิจัย

## Smoke test

```bash
python3 make_smoke_dataset.py --output-dir smoke_data
python3 rule_router.py \
  --dataset smoke_data/labeled.csv \
  --config configs/rule_config.json \
  --output-dir smoke_data/routed
python3 train_xgboost.py \
  --dataset smoke_data/routed/ml_candidates.csv \
  --feature-config configs/feature_config.json \
  --profile hybrid \
  --output-dir smoke_artifacts \
  --n-estimators 40
python3 predict.py \
  --model smoke_artifacts/wazuh_xgboost.joblib \
  --dataset smoke_data/routed/ml_candidates.csv \
  --output smoke_artifacts/all_predictions.csv
```

หรือรันทั้งหมดด้วย `bash run_smoke_test.sh`
