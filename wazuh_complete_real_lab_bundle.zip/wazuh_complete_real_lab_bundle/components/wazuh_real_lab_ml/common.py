#!/usr/bin/env python3
"""Shared constants and helpers for the real-lab training package."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Iterable


LABEL_TO_ID = {"Safe": 0, "Suspicious": 1, "Dangerous": 2}
ID_TO_LABEL = {value: key for key, value in LABEL_TO_ID.items()}
LABEL_ALIASES = {
    "Safe": "Safe",
    "Suspicious": "Suspicious",
    "Dangerous": "Dangerous",
    "Normal": "Safe",
    "Pre_Compromise": "Suspicious",
    "Post_Compromise": "Dangerous",
}
FORBIDDEN_TOKENS = (
    "provenance", "marker", "session_id", "session_internal", "raw_log",
    "full_log", "source_ip", "src_ip", "destination_ip", "dest_ip",
    "username", "srcuser", "attacker", "reviewer",
)
IDENTIFIER_COLUMNS = {
    "event_id", "operation_id", "timestamp", "attack_type", "attack_group",
    "class_3", "binary_label", "rule_decision", "rule_reason",
}


def read_jsonl(path: Path) -> Iterable[dict[str, Any]]:
    with path.open("r", encoding="utf-8") as stream:
        for line_number, line in enumerate(stream, 1):
            if not line.strip():
                continue
            try:
                item = json.loads(line)
            except json.JSONDecodeError as exc:
                raise ValueError(f"{path}:{line_number}: invalid JSON: {exc}") from exc
            if not isinstance(item, dict):
                raise ValueError(f"{path}:{line_number}: expected a JSON object")
            yield item


def canonical_label(value: object) -> str:
    key = str(value)
    if key not in LABEL_ALIASES:
        raise ValueError(f"unknown label: {key!r}")
    return LABEL_ALIASES[key]


def leakage_columns(columns: Iterable[str]) -> list[str]:
    result = []
    for column in columns:
        lowered = column.lower()
        if column in IDENTIFIER_COLUMNS or any(token in lowered for token in FORBIDDEN_TOKENS):
            result.append(column)
    return sorted(result)


def load_feature_profile(path: Path, profile: str) -> tuple[list[str], list[str]]:
    config = json.loads(path.read_text(encoding="utf-8"))
    if profile not in config:
        raise ValueError(f"unknown feature profile {profile!r}; choose from {sorted(config)}")
    selected = config[profile]
    categorical = [str(item) for item in selected.get("categorical", [])]
    numeric = [str(item) for item in selected.get("numeric", [])]
    overlap = set(categorical) & set(numeric)
    if overlap:
        raise ValueError(f"features appear in both categorical and numeric: {sorted(overlap)}")
    leaked = leakage_columns(categorical + numeric)
    if leaked:
        raise ValueError(f"feature config contains leakage-prone columns: {leaked}")
    return categorical, numeric

