#!/usr/bin/env python3
"""Generate synthetic data that exercises every rule path and ML class."""

from __future__ import annotations

import argparse
from datetime import datetime, timedelta, timezone
from pathlib import Path

import pandas as pd


def base_row(operation: int, sequence: int, when: datetime) -> dict[str, object]:
    return {
        "event_id": f"smoke-{operation:03d}-{sequence:03d}",
        "operation_id": f"op-{operation:03d}",
        "timestamp": when.isoformat().replace("+00:00", "Z"),
        "agent_name": f"sensor-{operation % 4:02d}",
        "source_system": "wazuh",
        "event_type": "authentication",
        "event_status": "success",
        "protocol": "tcp",
        "event_action": "normal_login",
        "rule_groups": "authentication",
        "mitre_id": "none",
        "rule_level": 3,
        "stage_weight": 0,
        "source_is_private": 1,
        "destination_is_private": 1,
        "network_bytes": 500,
        "network_packets": 8,
        "audit_event_present": 0,
        "process_present": 0,
        "parent_process_present": 0,
        "file_change": 0,
        "privilege_change": 0,
        "asset_importance": 2,
        "source_events_previous_5m": 2,
        "failed_logins_previous_10m": 0,
        "scans_previous_5m": 0,
        "host_events_previous_5m": 2,
        "network_alerts_previous_5m": 0,
        "audit_events_previous_5m": 0,
        "process_executions_previous_10m": 0,
        "file_changes_previous_10m": 0,
        "privilege_changes_previous_30m": 0,
        "cross_source_count_previous_10m": 1,
        "previous_stage_max_30m": 0,
        "chain_length_previous_30m": 1,
        "hour": when.hour,
        "day_of_week": when.weekday(),
        "is_after_hours": int(when.hour < 7 or when.hour >= 19),
        "class_3": "Safe",
        "attack_type": "Benign",
        "provenance": "synthetic smoke-test generator",
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--operations", type=int, default=30)
    args = parser.parse_args()
    if args.operations < 15:
        raise ValueError("use at least 15 operations so every grouped split can contain all classes")

    rows: list[dict[str, object]] = []
    origin = datetime(2026, 1, 1, tzinfo=timezone.utc)
    for operation in range(args.operations):
        start = origin + timedelta(hours=operation * 2)
        sequence = 0

        # Known-noise route.
        for offset in range(2):
            row = base_row(operation, sequence, start + timedelta(seconds=offset))
            row.update(event_action="package_update", event_type="maintenance", class_3="Safe")
            rows.append(row)
            sequence += 1

        # Aggregation route (12 repeated scan alerts in one five-minute bucket).
        for offset in range(12):
            row = base_row(operation, sequence, start + timedelta(seconds=20 + offset))
            row.update(
                source_system="suricata", event_type="network", event_status="blocked",
                event_action="network_scan", rule_groups="reconnaissance", mitre_id="T1046",
                rule_level=7, scans_previous_5m=12, network_alerts_previous_5m=12,
                class_3="Suspicious", attack_type="Network_Scan",
            )
            rows.append(row)
            sequence += 1

        # Critical route.
        row = base_row(operation, sequence, start + timedelta(minutes=1))
        row.update(
            source_system="auditd", event_type="privilege", event_action="sudo_group_change",
            rule_groups="privilege_escalation", mitre_id="T1548", rule_level=13,
            audit_event_present=1, process_present=1, parent_process_present=1,
            privilege_change=1, privilege_changes_previous_30m=2,
            class_3="Dangerous", attack_type="Privilege_Escalation",
        )
        rows.append(row)
        sequence += 1

        # Three ambiguous events routed to ML: one example for every class.
        safe = base_row(operation, sequence, start + timedelta(minutes=2))
        safe.update(network_bytes=700 + operation, source_events_previous_5m=2 + operation % 2)
        rows.append(safe)
        sequence += 1

        suspicious = base_row(operation, sequence, start + timedelta(minutes=3))
        suspicious.update(
            source_system="suricata", event_type="authentication", event_status="failed",
            event_action="unusual_authentication", rule_groups="authentication|brute_force",
            mitre_id="T1110", rule_level=8, stage_weight=1,
            source_is_private=0, failed_logins_previous_10m=9 + operation % 3,
            source_events_previous_5m=12, network_alerts_previous_5m=5,
            cross_source_count_previous_10m=2, previous_stage_max_30m=1,
            chain_length_previous_30m=2, class_3="Suspicious", attack_type="Brute_Force",
        )
        rows.append(suspicious)
        sequence += 1

        dangerous = base_row(operation, sequence, start + timedelta(minutes=4))
        dangerous.update(
            source_system="auditd", event_type="process", event_status="success",
            event_action="suspicious_process_chain", rule_groups="execution|persistence",
            mitre_id="T1059", rule_level=10, stage_weight=3,
            source_is_private=0, network_bytes=50000 + operation * 10,
            network_packets=300, audit_event_present=1, process_present=1,
            parent_process_present=1, file_change=1, asset_importance=5,
            failed_logins_previous_10m=14, host_events_previous_5m=20,
            network_alerts_previous_5m=8, audit_events_previous_5m=9,
            process_executions_previous_10m=11, file_changes_previous_10m=5,
            cross_source_count_previous_10m=3, previous_stage_max_30m=2,
            chain_length_previous_30m=5, class_3="Dangerous", attack_type="Process_Chain",
        )
        rows.append(dangerous)

    args.output_dir.mkdir(parents=True, exist_ok=True)
    output = args.output_dir / "labeled.csv"
    pd.DataFrame(rows).to_csv(output, index=False)
    print(f"wrote {len(rows)} rows across {args.operations} operations to {output.resolve()}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
