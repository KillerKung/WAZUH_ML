#!/usr/bin/env python3
"""Fail fast on missing classes, groups, features, or leakage-prone schema."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import pandas as pd

from common import LABEL_TO_ID, canonical_label, leakage_columns, load_feature_profile


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--dataset", type=Path, required=True)
    parser.add_argument("--feature-config", type=Path, required=True)
    parser.add_argument("--profile", default="hybrid")
    parser.add_argument("--min-operations", type=int, default=6)
    args = parser.parse_args()

    frame = pd.read_csv(args.dataset)
    required = {"event_id", "operation_id", "class_3"}
    missing = required - set(frame.columns)
    errors: list[str] = []
    warnings: list[str] = []
    if missing:
        errors.append(f"missing required columns: {sorted(missing)}")
    categorical, numeric = load_feature_profile(args.feature_config, args.profile)
    missing_features = set(categorical + numeric) - set(frame.columns)
    if missing_features:
        errors.append(f"missing configured features: {sorted(missing_features)}")

    if "class_3" in frame:
        try:
            frame["class_3"] = frame["class_3"].map(canonical_label)
        except ValueError as exc:
            errors.append(str(exc))
        missing_classes = set(LABEL_TO_ID) - set(frame["class_3"].dropna())
        if missing_classes:
            errors.append(f"dataset lacks classes: {sorted(missing_classes)}")
    if "operation_id" in frame:
        operation_count = int(frame["operation_id"].nunique())
        if operation_count < args.min_operations:
            errors.append(f"only {operation_count} operations; require at least {args.min_operations}")
    else:
        operation_count = 0

    selected_leaks = leakage_columns(categorical + numeric)
    if selected_leaks:
        errors.append(f"selected features contain leakage: {selected_leaks}")
    schema_leaks = [column for column in leakage_columns(frame.columns) if column not in {"event_id", "operation_id", "class_3", "attack_type", "timestamp", "rule_decision", "rule_reason"}]
    if schema_leaks:
        warnings.append(f"metadata columns will not be features: {schema_leaks}")
    if frame.empty:
        errors.append("dataset is empty")
    duplicate_pairs = int(frame.duplicated(subset=[column for column in ("event_id", "operation_id") if column in frame]).sum())
    if duplicate_pairs:
        errors.append(f"duplicate event/operation rows: {duplicate_pairs}")

    result = {
        "valid": not errors,
        "rows": len(frame),
        "operations": operation_count,
        "class_counts": frame["class_3"].value_counts().to_dict() if "class_3" in frame else {},
        "feature_profile": args.profile,
        "feature_count": len(categorical) + len(numeric),
        "errors": errors,
        "warnings": warnings,
    }
    print(json.dumps(result, indent=2))
    return 0 if not errors else 1


if __name__ == "__main__":
    raise SystemExit(main())

