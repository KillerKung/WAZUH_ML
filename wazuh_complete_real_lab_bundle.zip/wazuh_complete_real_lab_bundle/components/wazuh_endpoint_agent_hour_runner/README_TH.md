# ตัวสร้าง Log บนเครื่อง Wazuh Agent จริง

แพ็กเกจนี้ติดตั้งและรันบน **เครื่อง Endpoint ที่มี Wazuh Agent** เช่น Ubuntu client/server จริงใน Lab ไม่ใช่เครื่อง Suricata Sensor

```text
Wazuh Agent Endpoint
├── agent_hour_runner.py
├── File / Process activity ──> Auditd หรือ Wazuh FIM
├── events.jsonl ─────────────> Wazuh Agent localfile
└── TCP / HTTP activity ──────> Lab server
                                  │
                                  └── Suricata Sensor มอง Trafficจากเครือข่าย
```

Suricata ไม่จำเป็นต้องติดตั้งบน Agent แต่ Sensor ต้องอยู่บนเส้นทางที่มองเห็น Traffic เช่น Gateway, bridge หรือ SPAN port

## กิจกรรมที่สร้าง

- Normal ทุก 4–10 วินาที: ไฟล์ใน sandbox, `id`, `uptime`, `uname`, TCP และ HTTP health check
- ทุกประมาณ 10 นาที: Network Scan simulation, Web path simulation และ Process/File chain simulation สลับกัน
- รันครบ 3,600 วินาทีแล้วหยุดเอง
- ไม่เดารหัสผ่าน ไม่แก้ผู้ใช้ ไม่แก้ sudoers ไม่ติดตั้ง web shell และไม่สแกน Public IP

## ติดตั้งบนเครื่อง Agent

ตรวจว่า Agent ทำงานก่อน:

```bash
sudo systemctl status wazuh-agent --no-pager
```

ติดตั้งแพ็กเกจ:

```bash
unzip wazuh_endpoint_agent_hour_runner.zip
cd wazuh_endpoint_agent_hour_runner
sudo bash install_on_agent.sh
```

Installer จะ:

1. ตรวจว่ามี `/var/ossec/etc/ossec.conf`
2. ติดตั้ง Runner ที่ `/opt/wazuh-lab/endpoint-agent/bin/`
3. เพิ่ม JSON localfile ให้ Wazuh Agent แบบ idempotent และสำรอง `ossec.conf`
4. สร้าง Ground-truth directory ที่ permission `0700`
5. ติดตั้ง systemd service แต่ยังไม่เริ่มการทดลอง

## ตั้งค่า

```bash
sudo nano /etc/wazuh-lab-agent/config.json
```

แก้ชื่อ Agent และ IP ของ **Lab server ปลายทาง** ไม่ใช่ IP ของ Suricata Sensor:

```json
"agent_name": "lab-endpoint-01",
"target_hosts": ["192.168.56.50"]
```

IP ต้องเป็น RFC1918, loopback, link-local หรือ IPv6 ULA เท่านั้น โปรแกรมจะปฏิเสธ Public IP

## ตรวจโดยไม่สร้างกิจกรรม

```bash
sudo python3 /opt/wazuh-lab/endpoint-agent/bin/agent_hour_runner.py \
  --config /etc/wazuh-lab-agent/config.json
```

ถ้าถูกต้องจะเห็น `status: dry-run`

## รันจริงหนึ่งชั่วโมงบน Agent

```bash
sudo systemctl start wazuh-agent-lab-hour.service
```

ดูสถานะ:

```bash
sudo systemctl status wazuh-agent-lab-hour.service --no-pager
sudo journalctl -u wazuh-agent-lab-hour.service -f
sudo tail -f /var/log/wazuh-lab-agent/events.jsonl
```

หยุดก่อนครบเวลา:

```bash
sudo systemctl stop wazuh-agent-lab-hour.service
```

SIGTERM จะทำให้ Runner เขียนเวลา `end` ของ operation ปัจจุบันก่อนจบ

## ไฟล์สำหรับ ML

```text
/var/log/wazuh-lab-agent/events.jsonl
/var/lib/wazuh-lab-agent/ground-truth/labels.jsonl
/var/lib/wazuh-lab-agent/ground-truth/operations.jsonl
```

- `events.jsonl`: Wazuh Agent อ่านและส่งไป Manager
- `labels.jsonl`: exact label ตาม `event_id` ห้ามตั้งให้ Wazuh อ่าน
- `operations.jsonl`: ใช้แบ่ง Train/Validation/Test ตาม operation

Label หลักคือ `Safe / Suspicious / Dangerous` และมีชื่อเดิม `Normal / Pre_Compromise / Post_Compromise` ให้ด้วย

## Auditd บน Agent

ถ้ามี Auditd และกฎจาก Lab เดิมอยู่แล้วไม่ต้องเพิ่มซ้ำ ถ้าต้องการให้ Agent สร้าง Audit events ด้วย:

```bash
sudo install -m 0640 configs/auditd_hour_runner.rules \
  /etc/audit/rules.d/wazuh-lab-endpoint-agent.rules
sudo augenrules --load
```

หากไม่มี Auditd ตัว Runner ยังส่ง Structured JSON ผ่าน Wazuh Agent ได้ตามปกติ

## ความสัมพันธ์กับ Suricata

ตัว Runner รันบน Endpoint และส่ง TCP/HTTP ไปยัง Lab server ส่วน Suricata Sensor มีหน้าที่ตรวจ Traffic ระหว่างทาง หาก Sensor ไม่ได้อยู่บนเส้นทาง Traffic จะไม่มี `eve.json` แม้ Wazuh Agent จะสร้าง Network activity แล้ว ดังนั้นควรตรวจ topology ก่อนเก็บ Dataset

ก่อนเทรน ML ให้ Alert ผ่าน Rule-based router ก่อน และส่งเฉพาะ `ml_candidate` เข้าโมเดล
