#!/usr/bin/env bash
set -Eeuo pipefail

pid_path=/run/wazuh-lab-agent-hour.pid
if [[ ! -s "$pid_path" ]]; then
  echo "No runner PID file found."
  exit 0
fi
runner_pid=$(<"$pid_path")
if [[ ! "$runner_pid" =~ ^[0-9]+$ ]]; then
  echo "Invalid PID file; inspect it manually: $pid_path" >&2
  exit 1
fi
if kill -0 "$runner_pid" 2>/dev/null; then
  kill -TERM "$runner_pid"
  echo "Stop requested for PID $runner_pid; the runner will close its current operation manifest."
else
  echo "Runner PID $runner_pid is no longer active."
fi
