#!/usr/bin/env bash
set -Eeuo pipefail

if [[ ${EUID} -ne 0 ]]; then
  echo "Run with sudo so Auditd can observe activity under /opt/wazuh-lab." >&2
  exit 1
fi

script_dir=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
installed_runner=/opt/wazuh-lab/endpoint-agent/bin/agent_hour_runner.py
runner_path="$script_dir/agent_hour_runner.py"
[[ -f "$installed_runner" ]] && runner_path="$installed_runner"
config_path=${1:-/etc/wazuh-lab-agent/config.json}
log_path=/var/log/wazuh-lab-agent/runner.out
pid_path=/run/wazuh-lab-agent-hour.pid

if [[ ! -f "$config_path" ]]; then
  echo "Config not found: $config_path" >&2
  echo "Run install_on_agent.sh or pass the path to an edited config.json." >&2
  exit 2
fi
if [[ -s "$pid_path" ]] && kill -0 "$(<"$pid_path")" 2>/dev/null; then
  echo "Runner is already active with PID $(<"$pid_path")" >&2
  exit 1
fi

install -d -m 0755 /var/log/wazuh-lab-agent
nohup python3 "$runner_path" \
  --config "$config_path" --execute >>"$log_path" 2>&1 &
runner_pid=$!
echo "$runner_pid" > "$pid_path"
echo "Started one-hour Wazuh lab workload: PID=$runner_pid log=$log_path"
