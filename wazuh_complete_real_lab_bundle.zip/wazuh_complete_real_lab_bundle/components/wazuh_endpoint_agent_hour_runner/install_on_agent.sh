#!/usr/bin/env bash
set -Eeuo pipefail

if [[ ${EUID} -ne 0 ]]; then
  echo "Run this installer with sudo on the endpoint that has Wazuh Agent." >&2
  exit 1
fi
if [[ ! -f /var/ossec/etc/ossec.conf ]]; then
  echo "Wazuh Agent configuration was not found at /var/ossec/etc/ossec.conf" >&2
  exit 1
fi

script_dir=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
install -d -m 0755 /opt/wazuh-lab/endpoint-agent/bin /var/log/wazuh-lab-agent
install -d -m 0700 /var/lib/wazuh-lab-agent/ground-truth /etc/wazuh-lab-agent
install -m 0755 "$script_dir/agent_hour_runner.py" /opt/wazuh-lab/endpoint-agent/bin/agent_hour_runner.py
if [[ ! -f /etc/wazuh-lab-agent/config.json ]]; then
  install -m 0600 "$script_dir/config.example.json" /etc/wazuh-lab-agent/config.json
fi
touch /var/log/wazuh-lab-agent/events.jsonl
chmod 0644 /var/log/wazuh-lab-agent/events.jsonl

python3 "$script_dir/configure_wazuh_agent.py" --ossec /var/ossec/etc/ossec.conf
if [[ -x /var/ossec/bin/wazuh-agentd ]]; then
  /var/ossec/bin/wazuh-agentd -t
fi
install -m 0644 "$script_dir/configs/wazuh-agent-lab-hour.service" /etc/systemd/system/wazuh-agent-lab-hour.service
systemctl daemon-reload
systemctl restart wazuh-agent

echo "Installed on this Wazuh endpoint agent. The workload has NOT been started."
echo "Edit /etc/wazuh-lab-agent/config.json, then run:"
echo "  python3 /opt/wazuh-lab/endpoint-agent/bin/agent_hour_runner.py --config /etc/wazuh-lab-agent/config.json"
echo "  systemctl start wazuh-agent-lab-hour.service"
