# Verification report

Verified on 2026-08-24 with Python 3.12.

- Python compilation passed.
- Both shell scripts passed `bash -n`.
- Default one-hour configuration passed dry-run validation.
- Four-second localhost self-test completed all three simulation scenarios.
- Self-test generated 20 Safe, 6 Suspicious, and 1 Dangerous structured events.
- Every event had exactly one matching ground-truth label.
- Every event operation ID existed in the operation manifest.
- Event log mode was 0644; ground-truth label and operation files were 0600.
- SIGTERM test closed the active operation and reported `status: stopped`.
- Public targets are rejected; only RFC1918, loopback, link-local, and IPv6 ULA targets are accepted.
- The Wazuh localfile installer is idempotent and backs up `ossec.conf` before replacement.
- The package is endpoint-oriented; Suricata is treated as a separate network observer.

Self-test counts validate software behavior only. They are not model-performance results.
