#!/usr/bin/env python3
"""Run normal activity and harmless simulations directly on a Wazuh endpoint agent."""

from __future__ import annotations

import argparse
import ipaddress
import json
import os
import random
import shutil
import signal
import socket
import subprocess
import sys
import time
import urllib.error
import urllib.request
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


STOP_REQUESTED = False
CLASS_ALIASES = {
    "Safe": "Normal",
    "Suspicious": "Pre_Compromise",
    "Dangerous": "Post_Compromise",
}


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def request_stop(_signum: int, _frame: object) -> None:
    global STOP_REQUESTED
    STOP_REQUESTED = True


def append_jsonl(path: Path, row: dict[str, Any], mode: int = 0o640) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as stream:
        stream.write(json.dumps(row, ensure_ascii=False, separators=(",", ":")) + "\n")
        stream.flush()
        os.fsync(stream.fileno())
    path.chmod(mode)


def require_lab_path(value: object, field: str) -> Path:
    path = Path(str(value)).expanduser().resolve()
    if "wazuh-lab" not in str(path):
        raise ValueError(f"{field} must be inside a path containing 'wazuh-lab': {path}")
    return path


def validate_targets(hosts: list[object]) -> list[str]:
    if not hosts:
        raise ValueError("target_hosts must contain at least one explicit lab target")
    validated: list[str] = []
    for raw_host in hosts:
        host = str(raw_host).strip()
        if not host:
            raise ValueError("target_hosts contains an empty value")
        try:
            answers = socket.getaddrinfo(host, None, type=socket.SOCK_STREAM)
        except socket.gaierror as exc:
            raise ValueError(f"cannot resolve target {host!r}: {exc}") from exc
        addresses = {answer[4][0].split("%")[0] for answer in answers}
        for address in addresses:
            parsed = ipaddress.ip_address(address)
            allowed_networks = (
                ipaddress.ip_network("10.0.0.0/8"),
                ipaddress.ip_network("172.16.0.0/12"),
                ipaddress.ip_network("192.168.0.0/16"),
                ipaddress.ip_network("127.0.0.0/8"),
                ipaddress.ip_network("169.254.0.0/16"),
                ipaddress.ip_network("fc00::/7"),
                ipaddress.ip_network("fe80::/10"),
                ipaddress.ip_network("::1/128"),
            )
            if not any(parsed.version == network.version and parsed in network for network in allowed_networks):
                raise ValueError(f"target {host!r} resolves to non-lab address {address}")
        validated.append(host)
    return validated


def validate_config(config: dict[str, Any], self_test: bool) -> dict[str, Any]:
    if config.get("authorized_lab") is not True:
        raise ValueError("set authorized_lab to true only for an isolated system you own or may test")
    required = {
        "duration_seconds", "normal_delay_min_seconds", "normal_delay_max_seconds",
        "attack_interval_seconds", "attack_jitter_seconds", "target_hosts", "target_ports",
        "web_paths", "work_root", "event_log", "ground_truth_root", "agent_name",
    }
    missing = required - set(config)
    if missing:
        raise ValueError(f"configuration missing fields: {sorted(missing)}")

    duration = float(config["duration_seconds"])
    delay_min = float(config["normal_delay_min_seconds"])
    delay_max = float(config["normal_delay_max_seconds"])
    attack_interval = float(config["attack_interval_seconds"])
    jitter = float(config["attack_jitter_seconds"])
    if not self_test and not 60 <= duration <= 21600:
        raise ValueError("duration_seconds must be between 60 and 21600 (six hours)")
    if not self_test and attack_interval < 300:
        raise ValueError("attack_interval_seconds must be at least 300")
    if delay_min <= 0 or delay_max < delay_min:
        raise ValueError("normal delays must be positive and max must be >= min")
    if jitter < 0 or jitter >= attack_interval:
        raise ValueError("attack_jitter_seconds must be >= 0 and less than attack interval")

    ports = [int(value) for value in config["target_ports"]]
    if not ports or len(ports) > 16 or any(port < 1 or port > 65535 for port in ports):
        raise ValueError("target_ports must contain 1-16 valid TCP ports")
    paths = [str(value) for value in config["web_paths"]]
    if not paths or any(not path.startswith("/lab-") for path in paths):
        raise ValueError("every web path must start with /lab-")

    checked = dict(config)
    checked["duration_seconds"] = duration
    checked["normal_delay_min_seconds"] = delay_min
    checked["normal_delay_max_seconds"] = delay_max
    checked["attack_interval_seconds"] = attack_interval
    checked["attack_jitter_seconds"] = jitter
    checked["target_ports"] = ports
    checked["web_paths"] = paths
    checked["target_hosts"] = ["127.0.0.1"] if self_test else validate_targets(list(config["target_hosts"]))
    checked["work_root"] = require_lab_path(config["work_root"], "work_root")
    checked["event_log"] = require_lab_path(config["event_log"], "event_log")
    checked["ground_truth_root"] = require_lab_path(config["ground_truth_root"], "ground_truth_root")
    return checked


class Runner:
    def __init__(self, config: dict[str, Any], self_test: bool = False) -> None:
        self.config = config
        self.self_test = self_test
        self.rng = random.Random(int(config.get("seed", time.time_ns())))
        self.session_id = f"session-{uuid.uuid4()}"
        self.run_root = Path(config["work_root"]) / self.session_id
        self.event_log = Path(config["event_log"])
        truth_root = Path(config["ground_truth_root"])
        self.labels_log = truth_root / "labels.jsonl"
        self.operations_log = truth_root / "operations.jsonl"
        self.normal_index = 0
        self.attack_index = 0
        self.active_operation: dict[str, Any] | None = None

    def emit(self, action: str, source: str, category: str, class_name: str, details: dict[str, Any]) -> None:
        event_id = f"agent-{uuid.uuid4()}"
        when = utc_now()
        operation_id = str(self.active_operation["operation_id"])
        event = {
            "event_id": event_id,
            "operation_id": operation_id,
            "timestamp": when,
            "source_system": "wazuh_agent_endpoint",
            "agent": {"name": str(self.config["agent_name"])},
            "event": {"category": category, "action": action, "status": "observed"},
            "lab": {
                "session_id": self.session_id,
                "phase": self.active_operation["kind"],
                "scenario": self.active_operation["scenario"],
                "safe_simulation": True,
            },
            "details": {"expected_observer": source, **details},
        }
        label = {
            "event_id": event_id,
            "operation_id": operation_id,
            "class_3": class_name,
            "legacy_class": CLASS_ALIASES[class_name],
            "attack_type": self.active_operation["scenario"],
            "provenance": "authorized_lab_agent_runner",
            "session_id": self.session_id,
        }
        append_jsonl(self.event_log, event, 0o644)
        append_jsonl(self.labels_log, label, 0o600)

    def begin_operation(self, kind: str, scenario: str) -> None:
        if self.active_operation:
            self.end_operation()
        self.active_operation = {
            "operation_id": f"op-{uuid.uuid4()}",
            "session_id": self.session_id,
            "agent_name": str(self.config["agent_name"]),
            "kind": kind,
            "scenario": scenario,
            "start": utc_now(),
        }

    def end_operation(self) -> None:
        if not self.active_operation:
            return
        completed = dict(self.active_operation)
        completed["end"] = utc_now()
        append_jsonl(self.operations_log, completed, 0o600)
        self.active_operation = None

    def normal_activity(self) -> None:
        choices = [self.normal_file, self.normal_process, self.normal_tcp, self.normal_web]
        choices[self.normal_index % len(choices)]()
        self.normal_index += 1

    def normal_file(self) -> None:
        path = self.run_root / "normal" / "heartbeat.txt"
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(f"{utc_now()} normal heartbeat\n", encoding="utf-8")
        _ = path.read_text(encoding="utf-8")
        self.emit("normal_file_activity", "auditd", "file", "Safe", {"path": str(path)})

    def normal_process(self) -> None:
        command = self.rng.choice([["/usr/bin/id"], ["/usr/bin/uptime"], ["/bin/uname", "-a"]])
        result = subprocess.run(command, capture_output=True, text=True, timeout=3, check=False)
        self.emit("normal_process", "auditd", "process", "Safe", {
            "executable": command[0], "return_code": result.returncode,
        })

    def tcp_connect(self, host: str, port: int) -> bool:
        try:
            with socket.create_connection((host, port), timeout=float(self.config.get("timeout_seconds", 1.5))):
                return True
        except OSError:
            return False

    def normal_tcp(self) -> None:
        host = self.rng.choice(self.config["target_hosts"])
        port = self.rng.choice(self.config["target_ports"])
        connected = self.tcp_connect(host, port)
        self.emit("normal_tcp_connect", "suricata", "network", "Safe", {
            "target": host, "port": port, "connected": connected,
        })

    def http_get(self, host: str, path: str) -> int | None:
        url = f"http://{host}{path}"
        request = urllib.request.Request(url, headers={"User-Agent": "Wazuh-Lab-Runner/1.0"})
        try:
            with urllib.request.urlopen(request, timeout=float(self.config.get("timeout_seconds", 1.5))) as response:
                response.read(256)
                return int(response.status)
        except urllib.error.HTTPError as exc:
            return int(exc.code)
        except (urllib.error.URLError, TimeoutError):
            return None

    def normal_web(self) -> None:
        host = self.rng.choice(self.config["target_hosts"])
        status = self.http_get(host, "/lab-health")
        self.emit("health_check", "suricata", "network", "Safe", {"target": host, "status": status})

    def recon_window(self) -> None:
        attempts = int(self.config.get("connections_per_port", 5))
        attempts = max(1, min(attempts, 8))
        for host in self.config["target_hosts"]:
            for port in self.config["target_ports"]:
                connected = sum(self.tcp_connect(host, port) for _ in range(attempts))
                self.emit("network_scan", "suricata", "network", "Suspicious", {
                    "target": host, "port": port, "attempts": attempts, "connected": connected,
                })

    def web_probe_window(self) -> None:
        for host in self.config["target_hosts"]:
            for path in self.config["web_paths"]:
                status = self.http_get(host, path)
                self.emit("web_scan", "suricata", "network", "Suspicious", {
                    "target": host, "path": path, "status": status,
                })

    def post_compromise_emulation(self) -> None:
        attack_dir = self.run_root / "post-compromise-emulation" / f"window-{self.attack_index:03d}"
        attack_dir.mkdir(parents=True, exist_ok=True)
        original = attack_dir / ".lab-staged-file"
        renamed = attack_dir / "lab-staged-file.done"
        original.write_text("harmless authorized lab marker\n", encoding="utf-8")
        original.chmod(0o600)
        shutil.copy2(original, renamed)
        subprocess.run(["/bin/sh", "-c", "true"], timeout=3, check=False)
        self.emit("suspicious_process_chain", "auditd", "process", "Dangerous", {
            "sandbox": str(attack_dir), "effects": "file create, chmod, copy, harmless shell true",
        })

    def attack_window(self) -> None:
        scenarios = [
            ("Network_Scan", self.recon_window),
            ("Web_Scan", self.web_probe_window),
            ("Process_Chain", self.post_compromise_emulation),
        ]
        scenario, action = scenarios[self.attack_index % len(scenarios)]
        self.begin_operation("attack_window", scenario)
        action()
        self.end_operation()
        self.attack_index += 1
        self.begin_operation("baseline", "Normal")

    def run(self) -> None:
        self.run_root.mkdir(parents=True, exist_ok=True)
        self.begin_operation("baseline", "Normal")
        started = time.monotonic()
        deadline = started + float(self.config["duration_seconds"])
        next_attack = started + float(self.config["attack_interval_seconds"])
        print(json.dumps({
            "status": "running", "session_id": self.session_id,
            "duration_seconds": self.config["duration_seconds"],
            "event_log": str(self.event_log), "labels_log": str(self.labels_log),
        }, indent=2))
        try:
            while not STOP_REQUESTED and time.monotonic() < deadline:
                self.normal_activity()
                now = time.monotonic()
                if now >= next_attack:
                    self.attack_window()
                    jitter = self.rng.uniform(-float(self.config["attack_jitter_seconds"]), float(self.config["attack_jitter_seconds"]))
                    next_attack = now + float(self.config["attack_interval_seconds"]) + jitter
                delay = self.rng.uniform(
                    float(self.config["normal_delay_min_seconds"]),
                    float(self.config["normal_delay_max_seconds"]),
                )
                time.sleep(min(delay, max(0.0, deadline - time.monotonic())))
        finally:
            self.end_operation()
            print(json.dumps({
                "status": "stopped" if STOP_REQUESTED else "completed",
                "session_id": self.session_id, "normal_events": self.normal_index,
                "attack_windows": self.attack_index, "ended_at": utc_now(),
            }, indent=2))


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--execute", action="store_true", help="perform the bounded lab activities")
    parser.add_argument("--self-test", action="store_true", help="run a short localhost-only integration test")
    args = parser.parse_args()
    raw = json.loads(args.config.read_text(encoding="utf-8"))
    config = validate_config(raw, args.self_test)

    if args.self_test:
        test_root = Path("/tmp/wazuh-lab-hour-runner-self-test")
        config.update({
            "duration_seconds": 4.0, "normal_delay_min_seconds": 0.15,
            "normal_delay_max_seconds": 0.25, "attack_interval_seconds": 1.0,
            "attack_jitter_seconds": 0.0, "work_root": test_root / "runs",
            "event_log": test_root / "events.jsonl",
            "ground_truth_root": test_root / "ground-truth",
        })
        args.execute = True

    if not args.execute:
        estimated = max(0, int((config["duration_seconds"] - 1e-9) // config["attack_interval_seconds"]))
        print(json.dumps({
            "status": "dry-run", "validated": True,
            "duration_seconds": config["duration_seconds"],
            "estimated_attack_windows": estimated,
            "targets": config["target_hosts"],
            "message": "No activity performed. Add --execute on the authorized lab agent.",
        }, indent=2))
        return 0

    signal.signal(signal.SIGINT, request_stop)
    signal.signal(signal.SIGTERM, request_stop)
    Runner(config, self_test=args.self_test).run()
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (ValueError, OSError, json.JSONDecodeError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        raise SystemExit(2)
