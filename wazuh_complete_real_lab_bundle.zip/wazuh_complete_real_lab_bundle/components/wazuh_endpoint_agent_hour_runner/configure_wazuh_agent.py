#!/usr/bin/env python3
"""Idempotently add the endpoint lab JSON log to a Wazuh Agent configuration."""

from __future__ import annotations

import argparse
import os
import re
import shutil
import tempfile
import xml.etree.ElementTree as ET
from datetime import datetime, timezone
from pathlib import Path


BEGIN = "  <!-- BEGIN WAZUH ENDPOINT AGENT LAB -->"
END = "  <!-- END WAZUH ENDPOINT AGENT LAB -->"
BLOCK = f"""{BEGIN}
  <localfile>
    <log_format>json</log_format>
    <location>/var/log/wazuh-lab-agent/events.jsonl</location>
    <label key="collector_role">endpoint_agent</label>
  </localfile>
{END}
"""


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--ossec", type=Path, default=Path("/var/ossec/etc/ossec.conf"))
    args = parser.parse_args()
    path = args.ossec.resolve()
    if not path.is_file():
        parser.error(f"Wazuh Agent configuration not found: {path}")
    original = path.read_text(encoding="utf-8")
    if (BEGIN in original) != (END in original):
        parser.error("found only one endpoint-lab marker; restore the backup or repair ossec.conf")
    if BEGIN in original and END in original:
        pattern = re.escape(BEGIN) + r".*?" + re.escape(END) + r"\n?"
        updated = re.sub(pattern, BLOCK, original, flags=re.DOTALL)
    else:
        position = original.rfind("</ossec_config>")
        if position < 0:
            parser.error(f"closing </ossec_config> not found in {path}")
        updated = original[:position] + BLOCK + original[position:]

    try:
        ET.fromstring(updated)
    except ET.ParseError as exc:
        parser.error(f"updated ossec.conf would not be valid XML: {exc}")

    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
    backup = path.with_name(f"{path.name}.endpoint-lab.{stamp}.bak")
    shutil.copy2(path, backup)
    mode = path.stat().st_mode
    with tempfile.NamedTemporaryFile("w", encoding="utf-8", dir=path.parent, delete=False) as stream:
        stream.write(updated)
        temporary = Path(stream.name)
    os.chmod(temporary, mode)
    os.replace(temporary, path)
    print(f"updated: {path}")
    print(f"backup:  {backup}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
