# Wazuh Complete Real-Lab Bundle

ชุดรวมสำหรับโครงงาน **Wazuh Alert Prioritization & Noise Reduction** ครอบคลุม Manager, Endpoint Agent, Suricata Sensor, Log Generator, Normalize, Rule-based และ XGBoost

## โครงสร้างเครื่อง

```text
Endpoint Agent ─── network traffic ───> Lab target
      │                       ▲
      │ Wazuh/Auditd          │ Suricata Sensor ต้องมองเห็นเส้นทางนี้
      ▼                       │
                   Wazuh Manager
                   ├── alerts.json
                   ├── Export/Normalize
                   ├── Rule-based router
                   └── ML training/prediction
```

เครื่องที่แนะนำ:

| เครื่อง | ตัวอย่าง IP | Component |
|---|---|---|
| Wazuh Manager | `192.168.56.10` | `components/wazuh_multisource_lab` และ `components/wazuh_real_lab_ml` |
| Suricata Sensor | `192.168.56.20` | `components/wazuh_multisource_lab/scripts/install_sensor.sh` |
| Endpoint Agent | `192.168.56.50` | `components/wazuh_endpoint_agent_hour_runner` |
| Lab target/Tester | private IP เท่านั้น | HTTP/SSH test service หรือ traffic source |

หากมีเพียง Manager และ Agent จะเก็บ Wazuh/Auditd/Structured events ได้ แต่ Suricata จะยังไม่เห็น Traffic ของเครื่องอื่นจนกว่าจะมี Sensor บน gateway/bridge/SPAN

## Components

```text
components/
├── wazuh_multisource_lab/
│   ├── ติดตั้ง Manager และ Sensor
│   ├── Suricata/Auditd rules
│   ├── Export Wazuh alerts
│   └── Normalize multi-source logs
├── wazuh_endpoint_agent_hour_runner/
│   ├── ติดตั้งบน Endpoint ที่มี Wazuh Agent
│   ├── Normal activity + periodic safe simulations
│   └── events/labels/operations JSONL
└── wazuh_real_lab_ml/
    ├── Assign operations
    ├── Merge exact labels
    ├── Rule-based router
    ├── Validate dataset
    ├── Train XGBoost
    └── Predict + priority
```

รายละเอียดหน้าที่ทุกไฟล์อยู่ใน `FILE_GUIDE_TH.md`

## 1. เตรียม Manager

อ่านเอกสารทางการ Wazuh รุ่นปัจจุบันก่อนใช้ Installer เนื่องจากซอฟต์แวร์และ repository เปลี่ยนตามเวลา

Installer ที่รวมมาอ้างอิงสาย `4.14` จาก `packages.wazuh.com` และต้องใช้กับ Ubuntu/Debian เท่านั้น หากหน้า Quickstart ปัจจุบันเปลี่ยนสายเวอร์ชัน ให้ใช้ Installation Assistant จากหน้าเอกสารทางการแทนการแก้ URL ด้วยการคาดเดา

```bash
cd components/wazuh_multisource_lab
sudo bash scripts/install_manager.sh
```

ตรวจ:

```bash
sudo systemctl status wazuh-manager wazuh-indexer wazuh-dashboard filebeat --no-pager
sudo /var/ossec/bin/agent_control -lc
```

## 2. เตรียม Endpoint Agent

คัดลอกทั้งโฟลเดอร์นี้ไปเครื่อง Endpoint:

```text
components/wazuh_endpoint_agent_hour_runner
```

บน Endpoint:

```bash
cd wazuh_endpoint_agent_hour_runner
sudo bash install_on_agent.sh
sudo nano /etc/wazuh-lab-agent/config.json
```

ทดสอบแบบไม่สร้างกิจกรรม:

```bash
sudo python3 /opt/wazuh-lab/endpoint-agent/bin/agent_hour_runner.py \
  --config /etc/wazuh-lab-agent/config.json
```

เริ่มหนึ่งชั่วโมง:

```bash
sudo systemctl start wazuh-agent-lab-hour.service
sudo journalctl -u wazuh-agent-lab-hour.service -f
```

## 3. เตรียม Suricata Sensor (ถ้ามีเครื่องที่สาม)

บน Sensor เท่านั้น:

```bash
cd components/wazuh_multisource_lab
sudo bash scripts/install_sensor.sh \
  --manager 192.168.56.10 \
  --interface enp0s8 \
  --home-net 192.168.56.0/24 \
  --agent-name lab-sensor-01
```

Sensor ต้องอยู่บนเส้นทาง Traffic หรือรับ Packet mirror ไม่เช่นนั้น `eve.json` จะไม่มี Traffic ระหว่าง Endpoint กับ Target

## 4. ติดตั้ง Python environment บน Manager

```bash
cd components/wazuh_real_lab_ml
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cd ../..
```

แพ็กเกจทดสอบด้วยเวอร์ชันที่ pin ไว้ใน `requirements.txt`

## 5. นำ Ground truth จาก Endpoint มาที่ Manager

ต้นฉบับอยู่ที่:

```text
/var/lib/wazuh-lab-agent/ground-truth/labels.jsonl
/var/lib/wazuh-lab-agent/ground-truth/operations.jsonl
```

อย่าเปลี่ยน permission ของต้นฉบับเป็น public ให้คัดลอกผ่านช่องทางที่ได้รับอนุญาตมายัง Manager เช่น:

```text
data/labels.jsonl
data/operations.jsonl
```

## 6. Export → Normalize → Label → Rule route

ใช้สคริปต์รวม:

```bash
bash scripts/manager_prepare_dataset.sh \
  --alerts /var/ossec/logs/alerts/alerts.json \
  --agent lab-endpoint-01 \
  --since 2026-08-25T00:00:00Z \
  --operations data/operations.jsonl \
  --labels data/labels.jsonl \
  --output-dir data/run-001
```

ผลลัพธ์:

```text
alerts_lab.jsonl
normalized.csv
with_operations.csv
unmatched.csv
labeled_all.csv
labeled.csv
routed/all_routed.csv
routed/ml_candidates.csv
routed/known_noise.csv
routed/aggregated.csv
routed/critical.csv
routed/rule_report.json
```

`labeled.csv` มีเฉพาะแถวที่มี exact provenance label ส่วน Alert จริงที่ยังไม่มี Label จะยังคงอยู่ใน `labeled_all.csv`

## 7. Train

```bash
bash scripts/manager_train_model.sh \
  --dataset data/run-001/routed/ml_candidates.csv \
  --output-dir artifacts/run-001-hybrid \
  --profile hybrid
```

โมเดล:

```text
artifacts/run-001-hybrid/wazuh_xgboost.joblib
```

หนึ่งชั่วโมงเหมาะสำหรับทดสอบ Pipeline ยังไม่เพียงพอเป็นโมเดล Production ควรเก็บอย่างน้อย 20–30 independent operations ต่อคลาสและแยก Test ด้วย `operation_id`

## 8. Predict

Alert ใหม่ต้องผ่าน Normalize และ Rule router ก่อน แล้วส่งเฉพาะ `ml_candidate`:

```bash
components/wazuh_real_lab_ml/.venv/bin/python \
  components/wazuh_real_lab_ml/predict.py \
  --model artifacts/run-001-hybrid/wazuh_xgboost.joblib \
  --dataset data/new/routed/ml_candidates.csv \
  --output predictions/prioritized.csv
```

## Classes

Canonical classes:

```text
Safe = 0
Suspicious = 1
Dangerous = 2
```

ชื่อเดิมยังถูกแปลงได้:

```text
Normal → Safe
Pre_Compromise → Suspicious
Post_Compromise → Dangerous
```

## ขอบเขตความปลอดภัย

- ใช้เฉพาะระบบและ Private network ที่ได้รับอนุญาต
- Generator ไม่เดารหัสผ่าน ไม่แก้บัญชีผู้ใช้ ไม่แก้ sudoers และไม่ติดตั้ง web shell
- Ground truth, session, marker, IP, username, raw/full log และ operation ID ห้ามเป็น ML features
- Rule-based ต้องทำงานก่อน ML
- เก็บ Raw alerts ไว้ตรวจย้อนหลัง
- Deploy โมเดลแบบ Shadow mode ก่อน ห้ามสั่ง Block อัตโนมัติทันที

## เอกสารทางการที่ต้องตรวจเมื่อ Deploy

- Wazuh Quickstart: https://documentation.wazuh.com/current/quickstart.html
- Wazuh Linux Agent: https://documentation.wazuh.com/current/installation-guide/wazuh-agent/wazuh-agent-package-linux.html
- Agent enrollment requirements: https://documentation.wazuh.com/current/user-manual/agent/agent-enrollment/requirements.html
- Suricata documentation: https://docs.suricata.io/en/latest/
