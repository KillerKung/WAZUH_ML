# คู่มือไฟล์ทั้งหมด

## ไฟล์ระดับบน

| ไฟล์ | หน้าที่ |
|---|---|
| `README_TH.md` | ขั้นตอนติดตั้งและ Workflow ทั้งระบบ |
| `FILE_GUIDE_TH.md` | อธิบายหน้าที่ของไฟล์ในชุด |
| `lab.env.example` | ตัวอย่าง IP/ชื่อเครื่องสำหรับจดค่า Lab |
| `scripts/manager_prepare_dataset.sh` | Export, Normalize, Assign, Label, Rule route และ Validate |
| `scripts/manager_train_model.sh` | Validate และ Train XGBoost |
| `scripts/verify_bundle.sh` | ตรวจ Python/Shell/JSON และ Smoke test |

## `components/wazuh_multisource_lab`

| ไฟล์ | เครื่อง | หน้าที่ |
|---|---|---|
| `scripts/install_manager.sh` | Manager | ติดตั้ง Wazuh all-in-one |
| `scripts/install_sensor.sh` | Sensor | ติดตั้ง Wazuh Agent + Suricata + Auditd |
| `scripts/verify_lab.sh` | Sensor | ตรวจบริการและไฟล์ Log |
| `scripts/remove_lab_rules.sh` | Sensor | ถอดเฉพาะกฎ Lab |
| `scripts/safe_sensor_events.sh` | Sensor | สร้าง File/Process events ที่ไม่ทำลายระบบ |
| `scripts/safe_tester_traffic.sh` | Tester | สร้าง Traffic ไปยัง Sensor/Target แบบจำกัด |
| `tools/configure_sensor.py` | Sensor | เพิ่ม localfile และตั้งค่า Suricata แบบ idempotent |
| `tools/export_wazuh_alerts.py` | Manager | Export Alert ตาม Agent และเวลา |
| `tools/normalize_multisource.py` | Manager | แปลง Wazuh/Suricata/Auditd เป็น Common CSV |
| `tools/validate_normalized.py` | Manager | ตรวจ Schema และ Leakage ของ CSV |
| `tools/generate_multisource_events.py` | Lab test | สร้างข้อมูลจำลองเพื่อ Smoke test |
| `tools/train_lifecycle_model.py` | Legacy | Pipeline รุ่นเดิม ใช้ศึกษา/เปรียบเทียบ |
| `tools/predict_lifecycle.py` | Legacy | Prediction รุ่นเดิม |
| `configs/suricata/local.rules` | Sensor | กฎ Suricata สำหรับ Lab |
| `configs/auditd/wazuh-lab.rules` | Sensor | กฎ Auditd ที่ไม่ immutable |
| `configs/wazuh/ossec_localfiles.xml` | Sensor | ตัวอย่าง Wazuh localfile |

ไฟล์ Legacy train/predict ไม่ใช่ตัวหลัก ตัวหลักอยู่ใน `components/wazuh_real_lab_ml`

## `components/wazuh_endpoint_agent_hour_runner`

| ไฟล์ | หน้าที่ |
|---|---|
| `agent_hour_runner.py` | Normal activity และ periodic safe simulations บน Endpoint |
| `config.example.json` | ระยะเวลา Target และ path ของ Generator |
| `configure_wazuh_agent.py` | เพิ่ม JSON localfile ให้ Wazuh Agent พร้อม Backup |
| `install_on_agent.sh` | ติดตั้ง Runner และ systemd service บน Endpoint |
| `run_one_hour.sh` | รัน Background แบบ PID สำหรับกรณีไม่ใช้ systemd |
| `stop_runner.sh` | ขอหยุด Background runner |
| `configs/wazuh-agent-lab-hour.service` | systemd unit รันหนึ่งชั่วโมง |
| `configs/auditd_hour_runner.rules` | กฎ Auditd เฉพาะ sandbox บน Endpoint |
| `configs/ossec_localfile.xml` | localfile สำหรับ `events.jsonl` |
| `TEST_REPORT.md` | ผลตรวจแพ็กเกจ |

## `components/wazuh_real_lab_ml`

| ไฟล์ | หน้าที่ |
|---|---|
| `common.py` | Label mapping, leakage guard และ feature loader |
| `assign_operations.py` | จับคู่ Event กับช่วง Operation โดยไม่ใช้เวลาเดา Label |
| `merge_labels.py` | Exact one-to-one label join ด้วย `event_id` |
| `rule_router.py` | คัด Critical, Known noise, Aggregate และ ML candidate |
| `validate_training_data.py` | ตรวจ Features, Classes, Operations และ Leakage |
| `train_xgboost.py` | Grouped split, preprocessing, train, threshold และ metrics |
| `predict.py` | Probability, Dangerous threshold, risk score และ priority |
| `configs/rule_config.json` | เงื่อนไข Rule-based |
| `configs/feature_config.json` | Behavioral และ Hybrid feature profiles |
| `make_smoke_dataset.py` | สร้างข้อมูลจำลองสำหรับตรวจ Pipeline |
| `run_smoke_test.sh` | Smoke test Rule → Train → Predict |
| `requirements.txt` | Python versions ที่ใช้ทดสอบ |

## ไฟล์ที่เกิดขึ้นระหว่างรันจริง

บน Endpoint:

```text
/var/log/wazuh-lab-agent/events.jsonl
/var/lib/wazuh-lab-agent/ground-truth/labels.jsonl
/var/lib/wazuh-lab-agent/ground-truth/operations.jsonl
```

บน Manager:

```text
/var/ossec/logs/alerts/alerts.json
data/<run>/alerts_lab.jsonl
data/<run>/normalized.csv
data/<run>/labeled.csv
data/<run>/routed/ml_candidates.csv
artifacts/<model>/wazuh_xgboost.joblib
artifacts/<model>/metrics.json
artifacts/<model>/confusion_matrix_test.csv
artifacts/<model>/feature_importance.csv
```
