# Complete bundle verification

Verified on 2026-08-25.

## Static checks

- All Python files passed `py_compile`.
- All shell files passed `bash -n`.
- All JSON configuration files parsed successfully.
- Top-level workflow scripts accepted and displayed their documented arguments.

## Integrated dataset workflow

The complete `manager_prepare_dataset.sh` path was tested with 30 independent controlled operations:

```text
Export → Normalize → Assign operations → Merge exact labels
→ Select labeled rows → Rule router → Training validation
```

Results:

- 1,320 alerts exported and normalized.
- Sources: 810 Suricata, 330 Wazuh, 180 Auditd.
- All 1,320 rows matched an operation and an exact label.
- Rule router produced 660 aggregated, 630 ML-candidate, and 30 critical rows.
- ML candidates contained 360 Safe, 210 Suspicious, and 60 Dangerous rows.
- All three classes were present across 30 operations.
- No Dangerous row was routed to known noise or aggregation.
- Hybrid feature validation passed with 35 configured features.

The component-level ML and endpoint packages also include their own `TEST_REPORT.md` files. Synthetic integration results verify software behavior only and are not research-performance evidence.
