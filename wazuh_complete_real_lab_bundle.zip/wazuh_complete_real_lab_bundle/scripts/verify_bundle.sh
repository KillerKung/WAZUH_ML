#!/usr/bin/env bash
set -Eeuo pipefail

script_dir=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
bundle_root=$(cd -- "$script_dir/.." && pwd)

python3 -m py_compile \
  "$bundle_root"/components/wazuh_multisource_lab/tools/*.py \
  "$bundle_root"/components/wazuh_endpoint_agent_hour_runner/*.py \
  "$bundle_root"/components/wazuh_real_lab_ml/*.py

for shell_file in \
  "$bundle_root"/scripts/*.sh \
  "$bundle_root"/components/wazuh_multisource_lab/scripts/*.sh \
  "$bundle_root"/components/wazuh_endpoint_agent_hour_runner/*.sh \
  "$bundle_root"/components/wazuh_real_lab_ml/*.sh; do
  bash -n "$shell_file"
done

python3 - "$bundle_root" <<'PY'
import json
import sys
from pathlib import Path

root = Path(sys.argv[1])
for path in root.rglob("*.json"):
    json.loads(path.read_text(encoding="utf-8"))
print("Python, Shell and JSON checks passed")
PY

ml_python="$bundle_root/components/wazuh_real_lab_ml/.venv/bin/python"
if [[ -x "$ml_python" ]]; then
  (
    cd "$bundle_root/components/wazuh_real_lab_ml"
    PATH="$(dirname "$ml_python"):$PATH" bash run_smoke_test.sh
  )
  echo "ML smoke test passed"
else
  echo "Static checks passed; ML smoke test skipped because .venv is not included."
fi
