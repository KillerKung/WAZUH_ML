#!/usr/bin/env bash
set -Eeuo pipefail

alerts=""
agent=""
since=""
operations=""
labels=""
output_dir=""

usage() {
  echo "Usage: $0 --alerts FILE --agent NAME --since ISO8601 --operations FILE --labels FILE --output-dir DIR"
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --alerts) alerts=${2:-}; shift 2 ;;
    --agent) agent=${2:-}; shift 2 ;;
    --since) since=${2:-}; shift 2 ;;
    --operations) operations=${2:-}; shift 2 ;;
    --labels) labels=${2:-}; shift 2 ;;
    --output-dir) output_dir=${2:-}; shift 2 ;;
    -h|--help) usage; exit 0 ;;
    *) echo "Unknown argument: $1" >&2; usage >&2; exit 2 ;;
  esac
done

for value_name in alerts agent since operations labels output_dir; do
  if [[ -z ${!value_name} ]]; then
    echo "Missing --${value_name//_/-}" >&2
    usage >&2
    exit 2
  fi
done
for input_file in "$alerts" "$operations" "$labels"; do
  if [[ ! -f "$input_file" ]]; then
    echo "Input file not found: $input_file" >&2
    exit 1
  fi
done

script_dir=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
bundle_root=$(cd -- "$script_dir/.." && pwd)
lab_root="$bundle_root/components/wazuh_multisource_lab"
ml_root="$bundle_root/components/wazuh_real_lab_ml"
python_bin=python3
if [[ -x "$ml_root/.venv/bin/python" ]]; then
  python_bin="$ml_root/.venv/bin/python"
fi
if ! "$python_bin" -c 'import pandas' >/dev/null 2>&1; then
  echo "pandas is unavailable. Create components/wazuh_real_lab_ml/.venv and install requirements.txt" >&2
  exit 1
fi

mkdir -p "$output_dir"
"$python_bin" "$lab_root/tools/export_wazuh_alerts.py" \
  --input "$alerts" --output "$output_dir/alerts_lab.jsonl" \
  --agent "$agent" --since "$since"
"$python_bin" "$lab_root/tools/normalize_multisource.py" \
  --alerts "$output_dir/alerts_lab.jsonl" --output "$output_dir/normalized.csv"
"$python_bin" "$ml_root/assign_operations.py" \
  --dataset "$output_dir/normalized.csv" --manifest "$operations" \
  --output "$output_dir/with_operations.csv" --unmatched-output "$output_dir/unmatched.csv"
"$python_bin" "$ml_root/merge_labels.py" \
  --dataset "$output_dir/with_operations.csv" --labels "$labels" \
  --output "$output_dir/labeled_all.csv" --allow-unlabeled

"$python_bin" - "$output_dir/labeled_all.csv" "$output_dir/labeled.csv" <<'PY'
import sys
import pandas as pd

source, target = sys.argv[1:]
frame = pd.read_csv(source)
required = ["event_id", "operation_id", "class_3"]
missing = set(required) - set(frame.columns)
if missing:
    raise SystemExit(f"labeled data missing columns: {sorted(missing)}")
selected = frame.dropna(subset=required).copy()
selected.to_csv(target, index=False)
print({
    "all_rows": len(frame),
    "exact_labeled_rows": len(selected),
    "classes": selected["class_3"].value_counts().to_dict(),
    "operations": int(selected["operation_id"].nunique()),
})
if selected.empty:
    raise SystemExit("no exact-labeled rows remain")
PY

"$python_bin" "$ml_root/rule_router.py" \
  --dataset "$output_dir/labeled.csv" \
  --config "$ml_root/configs/rule_config.json" \
  --output-dir "$output_dir/routed"
"$python_bin" "$ml_root/validate_training_data.py" \
  --dataset "$output_dir/routed/ml_candidates.csv" \
  --feature-config "$ml_root/configs/feature_config.json" \
  --profile hybrid

echo "Prepared dataset: $(cd -- "$output_dir" && pwd)"
