#!/usr/bin/env bash
set -Eeuo pipefail

dataset=""
output_dir=""
profile="hybrid"

usage() {
  echo "Usage: $0 --dataset FILE --output-dir DIR [--profile behavioral|hybrid]"
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --dataset) dataset=${2:-}; shift 2 ;;
    --output-dir) output_dir=${2:-}; shift 2 ;;
    --profile) profile=${2:-}; shift 2 ;;
    -h|--help) usage; exit 0 ;;
    *) echo "Unknown argument: $1" >&2; usage >&2; exit 2 ;;
  esac
done
if [[ -z "$dataset" || -z "$output_dir" ]]; then
  usage >&2
  exit 2
fi
if [[ ! -f "$dataset" ]]; then
  echo "Dataset not found: $dataset" >&2
  exit 1
fi
if [[ "$profile" != "behavioral" && "$profile" != "hybrid" ]]; then
  echo "Profile must be behavioral or hybrid" >&2
  exit 2
fi

script_dir=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
bundle_root=$(cd -- "$script_dir/.." && pwd)
ml_root="$bundle_root/components/wazuh_real_lab_ml"
python_bin="$ml_root/.venv/bin/python"
if [[ ! -x "$python_bin" ]]; then
  echo "Python environment not found: $python_bin" >&2
  echo "Create it and install $ml_root/requirements.txt first." >&2
  exit 1
fi

"$python_bin" "$ml_root/validate_training_data.py" \
  --dataset "$dataset" \
  --feature-config "$ml_root/configs/feature_config.json" \
  --profile "$profile"
"$python_bin" "$ml_root/train_xgboost.py" \
  --dataset "$dataset" \
  --feature-config "$ml_root/configs/feature_config.json" \
  --profile "$profile" \
  --output-dir "$output_dir"

echo "Model bundle: $(cd -- "$output_dir" && pwd)/wazuh_xgboost.joblib"
