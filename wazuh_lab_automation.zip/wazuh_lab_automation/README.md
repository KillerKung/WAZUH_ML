# Wazuh Lab Real-Telemetry Automation

ชุดนี้สร้าง network/host activity จริงใน Lab เพื่อให้ Suricata, Auditd, SSH,
Web server และ Wazuh สร้าง Log ตามปกติ โดยไม่เขียน event ปลอมเข้า Wazuh

## ความปลอดภัยที่ฝังไว้

- เป้าหมายต้องอยู่ใน `authorized_targets` แบบตรงตัว
- IP ที่ resolve ได้ต้องเป็น private หรือ loopback เท่านั้น
- Port scan จำกัดสูงสุด 64 ports, web paths 20 paths และ SSH probes 5 ครั้งต่อรอบ
- SSH probe ไม่เดารหัสผ่าน ใช้ invalid user และ public-key failure เท่านั้น
- Post-compromise เป็น harmless emulation: สร้าง marker แล้วลบทิ้ง และตรวจ policy ด้วย `sudo -n -l`
- ไม่มีการเปิด shell, exploit ช่องโหว่, persistence หรือเปลี่ยนสิทธิ์จริง
- หากไม่ใส่ `--execute` โปรแกรมจะเป็น dry-run

## ตำแหน่งติดตั้ง

คัดลอก `wazuh_lab_traffic.py` และ config ไปทั้ง Tester และ Sensor จากนั้นแก้ IP
`192.168.56.20` ให้เป็น IP ของ Sensor จริงใน Lab

```bash
cp lab_config.example.json lab_config.json
nano lab_config.json
chmod +x wazuh_lab_traffic.py
```

ตรวจสอบว่า interface ที่ Suricata monitor มองเห็น traffic จาก Tester และเพิ่ม
Auditd rule ให้เฝ้า directory ที่ตั้งใน `local_activity_root` เช่น:

```bash
sudo mkdir -p /tmp/wazuh-lab-activity
sudo auditctl -w /tmp/wazuh-lab-activity -p rwxa -k wazuh_lab_activity
```

ถ้าต้องการให้ rule คงอยู่หลัง reboot ให้ใส่บรรทัดต่อไปนี้ในไฟล์ใต้
`/etc/audit/rules.d/` แล้วโหลด rules ใหม่ตามระบบปฏิบัติการ:

```text
-w /tmp/wazuh-lab-activity -p rwxa -k wazuh_lab_activity
```

## ทดสอบก่อนโดยไม่สร้าง traffic

บน Tester:

```bash
python3 wazuh_lab_traffic.py --config lab_config.json --role tester --mode mixed --iterations 5
```

บน Sensor:

```bash
python3 wazuh_lab_traffic.py --config lab_config.json --role sensor --mode mixed --iterations 5
```

## รันจริง

เริ่ม Sensor role เพื่อสร้าง Auditd host activity:

```bash
sudo python3 wazuh_lab_traffic.py --config lab_config.json --role sensor --mode mixed --iterations 20 --execute
```

จากนั้นรัน Tester role เพื่อสร้าง traffic ที่ Suricata มองเห็น:

```bash
sudo python3 wazuh_lab_traffic.py --config lab_config.json --role tester --mode mixed --iterations 20 --execute
```

เลือกโหมดได้ดังนี้:

- `--mode noise`: Normal activity เท่านั้น
- `--mode attack`: Pre/Post-compromise emulation เท่านั้น
- `--mode mixed`: Normal ทุกครั้ง และ attack ทุกจำนวนรอบที่กำหนดใน `mixed_attack_every`

## ทำงานอัตโนมัติด้วย systemd timer

เริ่มจากทดลองคำสั่งแบบ manual ให้สำเร็จก่อน แล้วสร้าง service บนแต่ละเครื่องโดย
เปลี่ยน `--role` ให้ตรงกับเครื่อง:

```ini
[Unit]
Description=Wazuh authorized lab telemetry round

[Service]
Type=oneshot
WorkingDirectory=/opt/wazuh-lab-automation
ExecStart=/usr/bin/python3 /opt/wazuh-lab-automation/wazuh_lab_traffic.py --config /opt/wazuh-lab-automation/lab_config.json --role tester --mode mixed --iterations 1 --execute
```

ตัวอย่าง timer ทุก 5 นาที:

```ini
[Unit]
Description=Run Wazuh lab telemetry every five minutes

[Timer]
OnBootSec=2min
OnUnitActiveSec=5min
RandomizedDelaySec=60
Persistent=true

[Install]
WantedBy=timers.target
```

## Ground truth และ ML

ไฟล์ `ground_truth_path` มี `operation_id`, scenario และ label:

- `Normal`
- `Pre_Compromise`
- `Post_Compromise`

อย่าตั้ง Wazuh `localfile` ให้อ่านไฟล์ labels นี้ และอย่านำ `operation_id`, marker,
ชื่อ scenario หรือ provenance ไปเป็น feature ของโมเดล เพราะจะเกิด data leakage

เวลารวมข้อมูล ให้จับคู่ ground truth กับ Wazuh/Suricata/Auditd ด้วยช่วงเวลา,
source/destination IP และ operation window แทนการใส่ label ลงใน event ที่ตรวจจับ

ใช้เฉพาะระบบที่คุณเป็นเจ้าของหรือได้รับอนุญาต และควร snapshot VM ก่อนทดลอง
