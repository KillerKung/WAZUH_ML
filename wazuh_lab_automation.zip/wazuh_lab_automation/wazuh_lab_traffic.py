#!/usr/bin/env python3
"""Bounded traffic and host-activity generator for an authorized Wazuh lab.

The program does not inject synthetic events into Wazuh. It performs real,
low-impact actions so Suricata, Auditd, SSH, web-server and Wazuh logs can be
collected normally. Ground-truth labels are written to a separate JSONL file.
"""

from __future__ import annotations

import argparse
import ipaddress
import json
import os
import random
import shutil
import socket
import subprocess
import sys
import time
import urllib.error
import urllib.request
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


MAX_SCAN_PORTS = 64
MAX_WEB_PATHS = 20
MAX_SSH_PROBES = 5
USER_AGENT = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 Chrome/124 Safari/537.36"


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def load_config(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8") as handle:
        cfg = json.load(handle)
    required = {"authorized_lab", "target", "authorized_targets", "ground_truth_path"}
    missing = sorted(required - cfg.keys())
    if missing:
        raise ValueError(f"missing config keys: {', '.join(missing)}")
    return cfg


def validate_target(cfg: dict[str, Any]) -> list[str]:
    if cfg.get("authorized_lab") is not True:
        raise ValueError("authorized_lab must be true")

    target = str(cfg["target"]).strip()
    allowed = {str(item).strip() for item in cfg["authorized_targets"]}
    if target not in allowed:
        raise ValueError(f"target {target!r} is not explicitly listed in authorized_targets")

    infos = socket.getaddrinfo(target, None, type=socket.SOCK_STREAM)
    addresses = sorted({item[4][0] for item in infos})
    if not addresses:
        raise ValueError("target did not resolve")
    for address in addresses:
        ip = ipaddress.ip_address(address)
        if not (ip.is_private or ip.is_loopback):
            raise ValueError(f"refusing non-private target address: {address}")
    return addresses


def validate_activity_root(value: str) -> Path:
    root = Path(value).expanduser().resolve()
    if not root.is_absolute() or "wazuh-lab" not in str(root).lower():
        raise ValueError("local_activity_root must be an absolute sandbox path containing 'wazuh-lab'")
    forbidden = {Path("/"), Path("/etc"), Path("/usr"), Path("/var"), Path("/home"), Path("/root")}
    if root in forbidden:
        raise ValueError(f"unsafe local_activity_root: {root}")
    return root


class LabRunner:
    def __init__(self, cfg: dict[str, Any], execute: bool, role: str) -> None:
        self.cfg = cfg
        self.execute = execute
        self.role = role
        self.target = str(cfg["target"])
        self.run_id = str(uuid.uuid4())
        self.timeout = min(max(float(cfg.get("timeout_seconds", 1.5)), 0.2), 5.0)
        self.labels = Path(str(cfg["ground_truth_path"])).expanduser()
        self.rng = random.Random(cfg.get("random_seed"))

    def say(self, message: str) -> None:
        prefix = "EXEC" if self.execute else "DRY-RUN"
        print(f"[{utc_now()}] [{prefix}] {message}", flush=True)

    def label(self, scenario: str, lifecycle_class: str, result: str, source: str) -> None:
        record = {
            "timestamp": utc_now(),
            "operation_id": self.run_id,
            "scenario": scenario,
            "label": lifecycle_class,
            "result": result,
            "source_role": source,
            "target": self.target,
        }
        if not self.execute:
            self.say(f"would label {scenario} -> {lifecycle_class} ({result})")
            return
        self.labels.parent.mkdir(parents=True, exist_ok=True)
        with self.labels.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(record, ensure_ascii=False) + "\n")

    def pause(self) -> None:
        low = max(float(self.cfg.get("delay_min_seconds", 0.4)), 0.0)
        high = max(float(self.cfg.get("delay_max_seconds", 1.5)), low)
        delay = min(self.rng.uniform(low, high), 30.0)
        if self.execute:
            time.sleep(delay)

    def tcp_connect(self, port: int, scenario: str, label: str) -> None:
        self.say(f"TCP connect {self.target}:{port} ({scenario})")
        result = "planned"
        if self.execute:
            try:
                with socket.create_connection((self.target, port), timeout=self.timeout):
                    result = "connected"
            except (OSError, TimeoutError) as exc:
                result = f"connection_failed:{type(exc).__name__}"
        self.label(scenario, label, result, self.role)

    def http_get(self, path: str, scenario: str, label: str) -> None:
        scheme = str(self.cfg.get("http_scheme", "http"))
        port = int(self.cfg.get("http_port", 80))
        clean_path = "/" + path.lstrip("/")
        url = f"{scheme}://{self.target}:{port}{clean_path}"
        self.say(f"HTTP GET {url} ({scenario})")
        result = "planned"
        if self.execute:
            request = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
            try:
                with urllib.request.urlopen(request, timeout=self.timeout) as response:
                    response.read(256)
                    result = f"http_{response.status}"
            except urllib.error.HTTPError as exc:
                result = f"http_{exc.code}"
            except (urllib.error.URLError, TimeoutError, OSError) as exc:
                result = f"request_failed:{type(exc).__name__}"
        self.label(scenario, label, result, self.role)

    def normal_network(self) -> None:
        paths = list(self.cfg.get("normal_http_paths", ["/", "/index.html", "/robots.txt"]))
        if paths:
            self.http_get(self.rng.choice(paths), "normal_web_browsing", "Normal")
        ports = [int(p) for p in self.cfg.get("normal_tcp_ports", [22, 80])]
        if ports:
            self.tcp_connect(self.rng.choice(ports), "normal_service_connection", "Normal")

    def local_noise(self) -> None:
        root = validate_activity_root(str(self.cfg.get("local_activity_root", "/tmp/wazuh-lab-activity")))
        item = root / f"normal-{self.run_id[:8]}.txt"
        self.say(f"create/read/rename/delete normal file under {root}")
        result = "planned"
        if self.execute:
            root.mkdir(parents=True, exist_ok=True)
            item.write_text(f"normal lab activity {utc_now()}\n", encoding="utf-8")
            item.read_text(encoding="utf-8")
            renamed = item.with_suffix(".done")
            item.rename(renamed)
            renamed.unlink()
            result = "completed"
        self.label("normal_file_activity", "Normal", result, self.role)

    def bounded_port_scan(self) -> None:
        ports = [int(p) for p in self.cfg.get("scan_ports", [])]
        if not ports:
            return
        if len(ports) > MAX_SCAN_PORTS or any(p < 1 or p > 65535 for p in ports):
            raise ValueError(f"scan_ports must contain 1-{MAX_SCAN_PORTS} valid ports")
        self.rng.shuffle(ports)
        for port in ports:
            self.tcp_connect(port, "network_service_scan", "Pre_Compromise")
            self.pause()

    def bounded_web_scan(self) -> None:
        paths = list(self.cfg.get("web_scan_paths", []))
        if len(paths) > MAX_WEB_PATHS:
            raise ValueError(f"web_scan_paths is limited to {MAX_WEB_PATHS} entries")
        for path in paths:
            self.http_get(str(path), "web_path_scan", "Pre_Compromise")
            self.pause()

    def ssh_auth_probes(self) -> None:
        count = min(max(int(self.cfg.get("ssh_probe_count", 0)), 0), MAX_SSH_PROBES)
        if count == 0:
            return
        ssh = shutil.which("ssh")
        if not ssh:
            self.say("ssh client not found; skipping SSH authentication probes")
            return
        port = int(self.cfg.get("ssh_port", 22))
        user = str(self.cfg.get("invalid_ssh_user", "wazuh_lab_invalid_user"))
        command = [
            ssh, "-p", str(port), "-o", "BatchMode=yes", "-o", "PasswordAuthentication=no",
            "-o", "PreferredAuthentications=publickey", "-o", "StrictHostKeyChecking=no",
            "-o", "UserKnownHostsFile=/dev/null", "-o", f"ConnectTimeout={max(1, int(self.timeout))}",
            f"{user}@{self.target}", "true",
        ]
        for _ in range(count):
            self.say(f"single invalid-user SSH public-key probe to {self.target}:{port}")
            result = "planned"
            if self.execute:
                completed = subprocess.run(command, capture_output=True, text=True, timeout=self.timeout + 3)
                result = f"ssh_exit_{completed.returncode}"
            self.label("ssh_failed_login_probe", "Pre_Compromise", result, self.role)
            self.pause()

    def host_post_compromise_emulation(self) -> None:
        root = validate_activity_root(str(self.cfg.get("local_activity_root", "/tmp/wazuh-lab-activity")))
        marker = root / f"lab-marker-{self.run_id[:8]}.php"
        self.say(f"create harmless PHP marker under {root}; no PHP code is executed")
        result = "planned"
        if self.execute:
            root.mkdir(parents=True, exist_ok=True)
            marker.write_text("<?php /* WAZUH_LAB_MARKER: inert file */ ?>\n", encoding="utf-8")
            marker.chmod(0o644)
            marker.read_text(encoding="utf-8")
            marker.unlink()
            result = "completed_and_cleaned"
        self.label("web_shell_file_emulation", "Post_Compromise", result, self.role)

        self.say("run non-mutating identity and sudo-policy discovery")
        result = "planned"
        if self.execute:
            subprocess.run(["id"], capture_output=True, text=True, timeout=3, check=False)
            sudo = shutil.which("sudo")
            if sudo:
                completed = subprocess.run([sudo, "-n", "-l"], capture_output=True, text=True, timeout=5)
                result = f"sudo_policy_check_exit_{completed.returncode}"
            else:
                result = "id_only_sudo_not_installed"
        self.label("privilege_escalation_discovery_emulation", "Post_Compromise", result, self.role)

    def noise_round(self) -> None:
        if self.role in {"tester", "all"}:
            self.normal_network()
        if self.role in {"sensor", "all"}:
            self.local_noise()

    def attack_round(self) -> None:
        if self.role in {"tester", "all"}:
            self.bounded_port_scan()
            self.bounded_web_scan()
            self.ssh_auth_probes()
        if self.role in {"sensor", "all"}:
            self.host_post_compromise_emulation()

    def run(self, mode: str, iterations: int) -> None:
        for index in range(1, iterations + 1):
            self.run_id = str(uuid.uuid4())
            self.say(f"round {index}/{iterations}; operation_id={self.run_id}")
            if mode == "noise":
                self.noise_round()
            elif mode == "attack":
                self.attack_round()
            else:
                self.noise_round()
                every = max(int(self.cfg.get("mixed_attack_every", 5)), 1)
                if index % every == 0:
                    self.attack_round()
            self.pause()


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Generate real, bounded telemetry in an authorized Wazuh lab")
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--mode", choices=("noise", "attack", "mixed"), default="mixed")
    parser.add_argument("--role", choices=("tester", "sensor", "all"), required=True)
    parser.add_argument("--iterations", type=int, default=1)
    parser.add_argument("--execute", action="store_true", help="perform actions; without this flag only print the plan")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    try:
        if args.iterations < 1 or args.iterations > 100:
            raise ValueError("iterations must be between 1 and 100")
        cfg = load_config(args.config)
        addresses = validate_target(cfg)
        print(f"Validated private lab target {cfg['target']} -> {', '.join(addresses)}")
        LabRunner(cfg, execute=args.execute, role=args.role).run(args.mode, args.iterations)
        return 0
    except (ValueError, OSError, json.JSONDecodeError, subprocess.TimeoutExpired) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
