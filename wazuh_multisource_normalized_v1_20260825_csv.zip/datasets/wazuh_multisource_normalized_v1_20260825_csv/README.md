# Wazuh Multi-source Normalized Dataset v1 (CSV)

Dataset นี้ Normalize จาก Wazuh SSH events จริง 911 แถว เพื่อใช้เป็น schema กลางสำหรับรวม sshd, Suricata และ auditd ภายหลัง

## ไฟล์สำหรับ ML

- `train_normalized_events.csv`: ชุดฝึก 667 events
- `test_normalized_events.csv`: ชุดทดสอบ 244 events
- `normalized_events_all.csv`: ข้อมูลรวม 911 events
- `manifest.json`: schema, checksum, distribution และนิยาม feature

## Target

ใช้ `label_id` เป็น target: 0 = Normal, 1 = SSH_Brute_Force

ห้ามใช้ `scenario`, `label`, `split`, `event_id`, `operation_id`, `timestamp` และ `agent_name` เป็น feature โดยตรง เพราะเป็น metadata หรือเสี่ยง data leakage

## Rolling features

ทุกคอลัมน์ที่ลงท้ายด้วย `previous_*` นับเฉพาะเหตุการณ์ก่อนหน้า ไม่รวม event ปัจจุบัน ยกเว้น `cross_source_count_previous_10m` ซึ่งรวม source ของ event ปัจจุบันเพื่อให้ค่าต่ำสุดเป็น 1

ตอนนี้แหล่งข้อมูลมีเฉพาะ sshd ดังนั้น feature ของ Suricata/auditd จะเป็น 0 ตามจริง ไม่ได้สร้างข้อมูลปลอม เมื่อเพิ่มสองแหล่งนี้ค่อยคำนวณใหม่ตาม timestamp เดียวกัน

Timestamp ทุกแถวเป็น UTC ISO-8601 ที่ถูกต้อง เช่น `2026-08-25T10:00:00.000Z`
