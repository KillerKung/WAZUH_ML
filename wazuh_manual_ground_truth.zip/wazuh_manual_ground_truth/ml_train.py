#!/usr/bin/env python3
"""Merge manual Ground Truth, validate it, and train XGBoost."""

import argparse
import json
from datetime import datetime, timezone
from pathlib import Path

import joblib
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.metrics import classification_report, confusion_matrix
from sklearn.model_selection import GroupShuffleSplit
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder
from sklearn.utils.class_weight import compute_sample_weight
from xgboost import XGBClassifier


LABEL_TO_ID = {"Safe": 0, "Suspicious": 1, "Dangerous": 2}

CATEGORICAL_FEATURES = [
    "rule_id",
    "rule_groups",
    "decoder_name",
    "mitre_id",
]

NUMERIC_FEATURES = [
    "rule_level",
    "source_port",
    "destination_port",
    "source_is_private",
    "destination_is_private",
    "network_bytes",
    "network_packets",
    "has_network_evidence",
    "has_audit_evidence",
    "has_process_evidence",
    "has_file_evidence",
    "has_auth_evidence",
    "has_privilege_evidence",
    "host_events_previous_5m",
    "same_rule_previous_5m",
    "unique_rules_previous_10m",
    "high_level_events_previous_10m",
    "auth_events_previous_10m",
    "file_events_previous_10m",
    "privilege_events_previous_30m",
    "mitre_events_previous_30m",
    "rule_level_max_previous_10m",
    "hour",
    "day_of_week",
    "is_after_hours",
    "rule_count",
]

FEATURES = CATEGORICAL_FEATURES + NUMERIC_FEATURES


def load_approved_ground_truth(path):
    """รับเฉพาะ Label ที่มนุษย์ยืนยันเป็น approved แล้ว"""
    labels = pd.read_csv(path, dtype={"event_id": str, "incident_id": str})
    required = {
        "event_id", "manual_label", "incident_id", "confidence",
        "label_reason", "reviewer", "review_status",
    }
    missing = sorted(required - set(labels.columns))
    if missing:
        raise ValueError(f"Ground Truth ขาดคอลัมน์: {missing}")
    if labels["event_id"].duplicated().any():
        raise ValueError("Ground Truth มี event_id ซ้ำ")

    labels = labels[labels["review_status"].astype(str).str.lower() == "approved"].copy()
    if labels.empty:
        raise ValueError("ยังไม่มี Label ที่ review_status=approved")

    unknown = sorted(set(labels["manual_label"].dropna()) - set(LABEL_TO_ID))
    if unknown:
        raise ValueError(f"manual_label ต้องเป็น Safe/Suspicious/Dangerous เท่านั้น: {unknown}")
    if labels["incident_id"].isna().any() or (labels["incident_id"].str.strip() == "").any():
        raise ValueError("ทุก Label ต้องมี incident_id เพื่อแบ่ง Train/Test โดยไม่รั่ว")
    return labels


def merge_labels(candidates, labels):
    candidates = candidates.copy()
    candidates["event_id"] = candidates["event_id"].astype(str)
    merged = candidates.merge(
        labels[["event_id", "manual_label", "incident_id", "confidence", "reviewer"]],
        on="event_id", how="inner", validate="one_to_one",
    )
    if merged.empty:
        raise ValueError("ไม่มี event_id ที่ตรงกันระหว่าง ML Candidates และ Ground Truth")
    return merged


def split_by_incident(frame, labels, seed):
    """เหตุการณ์ Incident เดียวกันต้องอยู่ Train หรือ Test ฝั่งเดียวเท่านั้น"""
    if frame["incident_id"].nunique() < 6:
        raise ValueError("ควรมีอย่างน้อย 6 incident_id และควรมีหลาย Incident ต่อคลาส")

    for candidate_seed in range(seed, seed + 300):
        splitter = GroupShuffleSplit(n_splits=1, test_size=0.20, random_state=candidate_seed)
        train_index, test_index = next(
            splitter.split(frame, labels, groups=frame["incident_id"])
        )
        if set(labels.iloc[train_index]) == {0, 1, 2} and set(labels.iloc[test_index]) == {0, 1, 2}:
            return train_index, test_index, candidate_seed
    raise ValueError("แบ่ง Incident แล้ว Train/Test มีคลาสไม่ครบ กรุณาเขียน Ground Truth เพิ่ม")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", type=Path, default=Path("routed/ml_candidates.csv"))
    parser.add_argument("--ground-truth", type=Path, default=Path("ground_truth_manual.csv"))
    parser.add_argument("--output-dir", type=Path, default=Path("model"))
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args()

    candidates = pd.read_csv(args.input, dtype={"event_id": str, "rule_id": str})
    labels = load_approved_ground_truth(args.ground_truth)
    frame = merge_labels(candidates, labels)

    missing_features = sorted(set(FEATURES) - set(frame.columns))
    if missing_features:
        raise ValueError(f"ML Candidates ขาด Feature: {missing_features}")

    X = frame[FEATURES].copy()
    y = frame["manual_label"].map(LABEL_TO_ID).astype(int)
    train_index, test_index, split_seed = split_by_incident(frame, y, args.seed)

    preprocess = ColumnTransformer([
        ("categorical", Pipeline([
            ("impute", SimpleImputer(strategy="most_frequent")),
            ("onehot", OneHotEncoder(handle_unknown="ignore")),
        ]), CATEGORICAL_FEATURES),
        ("numeric", Pipeline([
            ("impute", SimpleImputer(strategy="median")),
        ]), NUMERIC_FEATURES),
    ])

    classifier = XGBClassifier(
        n_estimators=300,
        max_depth=5,
        learning_rate=0.05,
        subsample=0.8,
        colsample_bytree=0.8,
        objective="multi:softprob",
        num_class=3,
        eval_metric="mlogloss",
        tree_method="hist",
        random_state=args.seed,
        n_jobs=-1,
    )
    pipeline = Pipeline([("preprocess", preprocess), ("model", classifier)])
    weights = compute_sample_weight(class_weight="balanced", y=y.iloc[train_index])
    pipeline.fit(X.iloc[train_index], y.iloc[train_index], model__sample_weight=weights)

    predicted = pipeline.predict(X.iloc[test_index])
    report = classification_report(
        y.iloc[test_index], predicted, labels=[0, 1, 2],
        target_names=["Safe", "Suspicious", "Dangerous"],
        output_dict=True, zero_division=0,
    )
    matrix = confusion_matrix(y.iloc[test_index], predicted, labels=[0, 1, 2])
    dangerous_as_safe = int(((y.iloc[test_index].to_numpy() == 2) & (predicted == 0)).sum())

    args.output_dir.mkdir(parents=True, exist_ok=True)
    model_path = args.output_dir / "wazuh_xgboost.joblib"
    joblib.dump({
        "pipeline": pipeline,
        "features": FEATURES,
        "label_to_id": LABEL_TO_ID,
        "created_at": datetime.now(timezone.utc).isoformat(),
    }, model_path)

    metrics = {
        "feature_count": len(FEATURES),
        "approved_labeled_rows": len(frame),
        "train_rows": len(train_index),
        "test_rows": len(test_index),
        "split_seed": split_seed,
        "macro_f1": report["macro avg"]["f1-score"],
        "dangerous_recall": report["Dangerous"]["recall"],
        "dangerous_as_safe": dangerous_as_safe,
        "confusion_matrix": matrix.tolist(),
    }
    (args.output_dir / "metrics.json").write_text(json.dumps(metrics, indent=2), encoding="utf-8")
    print(json.dumps({"model": str(model_path), **metrics}, indent=2))


if __name__ == "__main__":
    main()

